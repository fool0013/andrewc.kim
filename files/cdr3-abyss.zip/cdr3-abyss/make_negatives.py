import os
import random
import pandas as pd

POS_CSV = "data/antigen_cdr3_pairs.csv"
OUT_CSV = "data/antigen_cdr3_pairs_with_negatives.csv"

def main():
    df_pos = pd.read_csv(POS_CSV)
    print("Loaded positives:", df_pos.shape)

    # Ensure label column exists and is 1 for positives
    df_pos["label"] = 1

    antigens = df_pos["antigen_seq"].tolist()
    cdr3s = df_pos["cdr3_seq"].tolist()
    n_pos = len(df_pos)

    # Set of existing positive pairs to avoid accidentally recreating them as negatives
    pos_pairs = set(zip(df_pos["antigen_seq"], df_pos["cdr3_seq"]))

    neg_records = []
    target_neg = n_pos  # 1:1 ratio; change if you want more negatives

    attempts = 0
    max_attempts = target_neg * 10  # just to be safe

    while len(neg_records) < target_neg and attempts < max_attempts:
        attempts += 1
        ag = random.choice(antigens)
        cd = random.choice(cdr3s)

        # Skip if this is actually one of the known positive pairs
        if (ag, cd) in pos_pairs:
            continue

        neg_records.append({
            "pdb": "DECOY",      # or keep some reference if you want
            "antigen_seq": ag,
            "cdr3_seq": cd,
            "label": 0,
        })

    df_neg = pd.DataFrame(neg_records)
    print("Generated negatives:", df_neg.shape)

    df_all = pd.concat([df_pos, df_neg], ignore_index=True)
    df_all = df_all.sample(frac=1.0, random_state=0).reset_index(drop=True)  # shuffle

    os.makedirs(os.path.dirname(OUT_CSV), exist_ok=True)
    df_all.to_csv(OUT_CSV, index=False)
    print("Saved combined dataset to:", OUT_CSV)
    print("Label counts:")
    print(df_all["label"].value_counts())

if __name__ == "__main__":
    main()
