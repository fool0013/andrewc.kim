import argparse
import numpy as np, torch, torch.nn as nn
from sklearn.model_selection import StratifiedGroupKFold
from sklearn.metrics import roc_auc_score

ap = argparse.ArgumentParser()
ap.add_argument("--data", default="data/windows.npz")
ap.add_argument("--folds", type=int, default=5)
ap.add_argument("--epochs", type=int, default=40)
ap.add_argument("--seeds", type=int, default=3)
ap.add_argument("--save", default="binder_model.pt")
args = ap.parse_args()

d = np.load(args.data)
windows, filled = d["windows"], d["filled"]
cdr3_emb, antigen_idx, cdr3_idx = d["cdr3_emb"], d["antigen_idx"], d["cdr3_idx"]
label = d["label"]
dim = cdr3_emb.shape[1]

window_mean = windows[filled].mean(0, keepdims=True)
window_std = windows[filled].std(0, keepdims=True) + 1e-8
windows = ((windows - window_mean) / window_std).astype(np.float32) * filled[..., None]
cdr3_emb = ((cdr3_emb - cdr3_emb.mean(0, keepdims=True)) / (cdr3_emb.std(0, keepdims=True) + 1e-8)).astype(np.float32)

print(f"{len(label)} pairs, {int(label.sum())} binders, {filled.sum(1).mean():.1f} windows per antigen")

class Binder(nn.Module):
    def __init__(self, dim, hidden=128, dropout=0.3):
        super().__init__()
        self.window_proj = nn.Sequential(nn.Linear(dim, hidden), nn.ReLU())
        self.cdr3_proj = nn.Sequential(nn.Linear(dim, hidden), nn.ReLU())
        self.score = nn.Sequential(
            nn.Linear(4 * hidden, hidden), nn.ReLU(), nn.Dropout(dropout), nn.Linear(hidden, 1)
        )

    def forward(self, window_batch, mask, cdr3_batch):
        w = self.window_proj(window_batch)
        c = self.cdr3_proj(cdr3_batch).unsqueeze(1).expand(-1, w.shape[1], -1)
        pair = torch.cat([w, c, w * c, (w - c).abs()], -1)
        per_window = self.score(pair).squeeze(-1).masked_fill(~mask, -1e9)
        return per_window.max(1).values

def batch_of(rows):
    return (
        torch.from_numpy(windows[antigen_idx[rows]]),
        torch.from_numpy(filled[antigen_idx[rows]]),
        torch.from_numpy(cdr3_emb[cdr3_idx[rows]]),
        torch.from_numpy(label[rows]).float(),
    )

def fit(train_rows, test_rows, seed):
    torch.manual_seed(seed)
    gen = torch.Generator().manual_seed(seed)
    shuffled = train_rows[torch.randperm(len(train_rows), generator=gen).numpy()]
    cut = max(2, int(0.15 * len(shuffled)))
    val_rows, fit_rows = shuffled[:cut], shuffled[cut:]

    model = Binder(dim)
    opt = torch.optim.AdamW(model.parameters(), lr=1e-3, weight_decay=1e-2)
    criterion = nn.BCEWithLogitsLoss()
    best_auc, best_state, stale = -1, None, 0

    for _ in range(args.epochs):
        model.train()
        order = fit_rows[torch.randperm(len(fit_rows), generator=gen).numpy()]
        for start in range(0, len(order), 32):
            rows = order[start:start + 32]
            if len(rows) < 2:
                continue
            w, m, c, y = batch_of(rows)
            opt.zero_grad()
            criterion(model(w, m, c), y).backward()
            opt.step()

        model.eval()
        with torch.no_grad():
            w, m, c, y = batch_of(val_rows)
            val_auc = roc_auc_score(label[val_rows], torch.sigmoid(model(w, m, c)).numpy())
        if val_auc > best_auc:
            best_auc, stale = val_auc, 0
            best_state = {k: v.clone() for k, v in model.state_dict().items()}
        else:
            stale += 1
            if stale >= 10:
                break

    model.load_state_dict(best_state)
    model.eval()
    with torch.no_grad():
        w, m, c, y = batch_of(test_rows)
        pred = torch.sigmoid(model(w, m, c)).numpy()
    return model, roc_auc_score(label[test_rows], pred), ((pred > 0.5) == (label[test_rows] > 0.5)).mean()

runs, best_overall, best_model = [], -1, None
for seed in range(args.seeds):
    folds = StratifiedGroupKFold(args.folds, shuffle=True, random_state=seed)
    aucs, accs = [], []
    for train_rows, test_rows in folds.split(np.zeros((len(label), 1)), label, groups=antigen_idx):
        model, auc, acc = fit(train_rows, test_rows, seed)
        aucs.append(auc)
        accs.append(acc)
        if auc > best_overall:
            best_overall, best_model = auc, model
    runs.append((np.mean(aucs), np.mean(accs)))
    print(f"seed {seed}: auc {np.mean(aucs):.3f} +/- {np.std(aucs):.3f}, acc {np.mean(accs) * 100:.1f}%")

auc_mean = np.mean([r[0] for r in runs])
acc_mean = np.mean([r[1] for r in runs])
print(f"grouped cv over {args.seeds} seeds: auc {auc_mean:.3f}, acc {acc_mean * 100:.1f}%")

torch.save(
    {"state_dict": best_model.state_dict(), "window_mean": window_mean, "window_std": window_std, "dim": dim},
    args.save,
)
print(f"saved {args.save}")
