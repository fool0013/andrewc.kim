import argparse, time
import numpy as np, pandas as pd, torch, esm

ap = argparse.ArgumentParser()
ap.add_argument("--csv", default="data/antigen_cdr3_pairs.csv")
ap.add_argument("--out", default="data/windows.npz")
ap.add_argument("--win", type=int, default=16)
ap.add_argument("--stride", type=int, default=8)
ap.add_argument("--max_windows", type=int, default=64)
ap.add_argument("--threads", type=int, default=4)
args = ap.parse_args()

torch.set_num_threads(args.threads)

model, alphabet = esm.pretrained.esm2_t12_35M_UR50D()
model.eval()
convert = alphabet.get_batch_converter()
layer = model.num_layers
dim = model.embed_dim

df = pd.read_csv(args.csv)
antigens = sorted(set(df.antigen_seq.astype(str)))
cdr3s = sorted(set(df.cdr3_seq.astype(str)))
print(f"{len(antigens)} antigens, {len(cdr3s)} cdr3s, dim {dim}")

def residues(seq):
    _, _, toks = convert([("x", seq)])
    with torch.no_grad():
        out = model(toks, repr_layers=[layer])["representations"][layer]
    return out[0, 1:1 + len(seq)]

windows = np.zeros((len(antigens), args.max_windows, dim), dtype=np.float32)
filled = np.zeros((len(antigens), args.max_windows), dtype=bool)
start = time.time()

for n, seq in enumerate(antigens):
    rep = residues(seq)
    offsets = list(range(0, max(1, len(seq) - args.win + 1), args.stride))
    if len(offsets) > args.max_windows:
        keep = np.linspace(0, len(offsets) - 1, args.max_windows).round().astype(int)
        offsets = [offsets[i] for i in keep]
    for k, off in enumerate(offsets):
        windows[n, k] = rep[off:off + args.win].mean(0).numpy()
        filled[n, k] = True
    if (n + 1) % 150 == 0:
        print(f"  {n + 1}/{len(antigens)} ({time.time() - start:.0f}s)")

cdr3_emb = np.zeros((len(cdr3s), dim), dtype=np.float32)
for n, seq in enumerate(cdr3s):
    cdr3_emb[n] = residues(seq).mean(0).numpy()

antigen_row = {s: i for i, s in enumerate(antigens)}
cdr3_row = {s: i for i, s in enumerate(cdr3s)}
np.savez_compressed(
    args.out,
    windows=windows,
    filled=filled,
    cdr3_emb=cdr3_emb,
    antigen_idx=df.antigen_seq.astype(str).map(antigen_row).to_numpy(),
    cdr3_idx=df.cdr3_seq.astype(str).map(cdr3_row).to_numpy(),
    label=df.label.to_numpy().astype(np.float32),
)
print(f"saved {args.out}, {filled.sum(1).mean():.1f} windows per antigen, {time.time() - start:.0f}s")
