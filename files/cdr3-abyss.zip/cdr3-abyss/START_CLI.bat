@echo off
cd /d %~dp0

call venv\Scripts\activate

python cdr3_cli_abyss.py

pause
