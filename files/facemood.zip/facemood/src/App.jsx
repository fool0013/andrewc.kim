import React, { useEffect, useRef, useState } from "react";

const clamp01 = (x) => Math.max(0, Math.min(1, x));
const dist = (a, b) => Math.hypot(a.x - b.x, a.y - b.y);

const LEFT_EYE = [33, 160, 158, 133, 153, 144];
const RIGHT_EYE = [263, 387, 385, 362, 380, 373];

function eyeOpenness(points, eye) {
  const [corner1, top1, top2, corner2, bottom2, bottom1] = eye.map((i) => points[i]);
  return (dist(top1, bottom1) + dist(top2, bottom2)) / (2 * dist(corner1, corner2));
}

function eyeAspectRatio(points) {
  return (eyeOpenness(points, LEFT_EYE) + eyeOpenness(points, RIGHT_EYE)) / 2;
}

function mouthAspectRatio(points) {
  return dist(points[13], points[14]) / dist(points[61], points[291]);
}

function browRaise(points) {
  const eyeCenter = { x: (points[33].x + points[133].x) / 2, y: (points[33].y + points[133].y) / 2 };
  const eyeWidth = dist(points[33], points[133]) || 1;
  return dist(points[105], eyeCenter) / eyeWidth;
}

function useKeysPerMinute() {
  const [keysPerMinute, setKeysPerMinute] = useState(0);
  const count = useRef(0);

  useEffect(() => {
    const onKey = (e) => { if (e.key.length === 1) count.current++; };
    window.addEventListener("keydown", onKey);
    const timer = setInterval(() => { setKeysPerMinute(count.current); count.current = 0; }, 60000);
    return () => { window.removeEventListener("keydown", onKey); clearInterval(timer); };
  }, []);

  return keysPerMinute;
}

function useFaceSignals(videoRef) {
  const [signals, setSignals] = useState({ eyesOpen: null, smiling: null, brow: null, headTilt: null, motion: 0 });
  const previous = useRef({ frame: null, brightness: 0 });

  useEffect(() => {
    let frameId = 0;
    let stopped = false;

    (async () => {
      const [{ createDetector, SupportedModels }, tf] = await Promise.all([
        import("@tensorflow-models/face-landmarks-detection"),
        import("@tensorflow/tfjs-core"),
      ]);
      await import("@tensorflow/tfjs-converter");
      await import("@tensorflow/tfjs-backend-webgl");
      await tf.setBackend("webgl");
      const detector = await createDetector(SupportedModels.MediaPipeFaceMesh, { runtime: "tfjs" });

      const canvas = document.createElement("canvas");
      const ctx = canvas.getContext("2d", { willReadFrequently: true });

      const loop = async () => {
        if (stopped) return;
        const video = videoRef.current;
        if (!video || !video.videoWidth) { frameId = requestAnimationFrame(loop); return; }

        const faces = await detector.estimateFaces(video, { flipHorizontal: true });

        const width = (canvas.width = video.videoWidth);
        const height = (canvas.height = video.videoHeight);
        ctx.drawImage(video, 0, 0, width, height);
        const pixels = ctx.getImageData(0, 0, width, height).data;
        const pixelCount = pixels.length / 4;

        const last = previous.current;
        const frame = new Float32Array(pixelCount);
        const hasLast = last.frame && last.frame.length === pixelCount;
        let total = 0;
        let change = 0;
        for (let i = 0; i < pixelCount; i++) {
          const y = 0.2126 * pixels[4 * i] + 0.7152 * pixels[4 * i + 1] + 0.0722 * pixels[4 * i + 2];
          frame[i] = y;
          total += y;
          if (hasLast) change += Math.abs(y - last.frame[i]);
        }

        const brightness = total / pixelCount;
        const motion = Math.min(1, change / pixelCount / 255);
        const brightnessChange = Math.min(Math.abs(brightness - last.brightness) / 50, 1);
        last.frame = frame;
        last.brightness = brightness;

        if (faces.length) {
          const points = faces[0].keypoints;
          setSignals({
            eyesOpen: clamp01((eyeAspectRatio(points) - 0.18) / 0.22),
            smiling: clamp01((mouthAspectRatio(points) - 0.3) / 0.4),
            brow: clamp01((browRaise(points) - 0.55) / 0.35),
            headTilt: clamp01(Math.abs(points[234].y - points[454].y) / 40),
            motion: clamp01(0.7 * motion + 0.3 * brightnessChange),
          });
        }
        frameId = requestAnimationFrame(loop);
      };
      loop();
    })();

    return () => { stopped = true; cancelAnimationFrame(frameId); };
  }, [videoRef]);

  return signals;
}

function inferMood({ eyesOpen, smiling, motion, keysPerMinute }) {
  const arousal = Math.max(motion, eyesOpen ?? 0);
  if (keysPerMinute > 220 || arousal > 0.8) return "energetic";
  if (keysPerMinute > 120 || (arousal > 0.5 && smiling < 0.3)) return "focus";
  if ((smiling ?? 0) < 0.15 && arousal < 0.25) return "melancholy";
  if (arousal < 0.45) return "chill";
  return "happy";
}

function Meter({ label, value }) {
  return (
    <div className="bg-slate-900 rounded-xl p-3 border border-slate-800">
      <div className="text-xs opacity-70 mb-1">{label}</div>
      {value == null ? (
        <div className="text-xs opacity-50">-</div>
      ) : (
        <div className="flex items-center gap-2">
          <div className="flex-1 h-2 bg-slate-800 rounded">
            <div className="h-2 rounded bg-lime-400" style={{ width: Math.round(value * 100) + "%" }} />
          </div>
          <div className="text-xs w-10 text-right">{Math.round(value * 100)}%</div>
        </div>
      )}
    </div>
  );
}

export default function App() {
  const videoRef = useRef(null);
  const [cameraOn, setCameraOn] = useState(false);
  const [error, setError] = useState("");
  const keysPerMinute = useKeysPerMinute();
  const signals = useFaceSignals(videoRef);
  const mood = inferMood({ ...signals, keysPerMinute });

  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: false });
      if (!videoRef.current) return;
      videoRef.current.srcObject = stream;
      await videoRef.current.play();
      setCameraOn(true);
      setError("");
    } catch {
      setError("couldn't open the camera. check permissions.");
    }
  };

  const stopCamera = () => {
    const video = videoRef.current;
    if (!video) return;
    if (video.srcObject) video.srcObject.getTracks().forEach((track) => track.stop());
    video.srcObject = null;
    setCameraOn(false);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100">
      <div className="max-w-5xl mx-auto px-4 py-8">
        <header className="flex items-center justify-between">
          <h1 className="text-2xl font-bold">facemood</h1>
          {cameraOn ? (
            <button onClick={stopCamera} className="px-4 py-2 rounded-2xl bg-rose-600 hover:bg-rose-500">stop camera</button>
          ) : (
            <button onClick={startCamera} className="px-4 py-2 rounded-2xl bg-indigo-600 hover:bg-indigo-500">start camera</button>
          )}
        </header>
        {error && <p className="mt-3 text-sm text-rose-400">{error}</p>}

        <section className="mt-6 grid md:grid-cols-2 gap-6">
          <div className="p-4 bg-slate-900/60 rounded-2xl">
            <div className="relative overflow-hidden rounded-xl bg-black/40">
              <video ref={videoRef} className="w-full aspect-video object-cover" muted playsInline />
            </div>
            <p className="mt-3 text-xs opacity-60">nothing gets uploaded. it all runs in your browser.</p>
          </div>

          <div className="p-4 bg-slate-900/60 rounded-2xl">
            <div className="grid grid-cols-2 gap-3">
              <Meter label="eyes open" value={signals.eyesOpen} />
              <Meter label="smiling" value={signals.smiling} />
              <Meter label="brow raise" value={signals.brow} />
              <Meter label="head tilt" value={signals.headTilt} />
              <Meter label="keys/min" value={keysPerMinute ? Math.min(keysPerMinute / 240, 1) : null} />
              <Meter label="motion" value={signals.motion} />
            </div>
            <p className="mt-4 text-sm">mood: <span className="font-semibold">{mood}</span></p>
          </div>
        </section>
      </div>
    </div>
  );
}
