import time

import cv2
import keyboard
import mss
import numpy as np
import win32api
import win32con

SCREEN_WIDTH = 1920
SCREEN_HEIGHT = 1080
CENTER_X = SCREEN_WIDTH // 2
CENTER_Y = SCREEN_HEIGHT // 2
FOV_SIZE = 6

LOWER_COLOR = np.array([145, 120, 180])
UPPER_COLOR = np.array([155, 255, 255])
KERNEL = np.ones((2, 2), np.uint8)

FIRE_DELAY = 0.15
TOGGLE_KEY = 'v'
QUIT_KEY = 'q'

monitor = {
    "top": CENTER_Y - FOV_SIZE // 2,
    "left": CENTER_X - FOV_SIZE // 2,
    "width": FOV_SIZE,
    "height": FOV_SIZE
}
bot_active = False

def toggle_bot(e):
    global bot_active
    bot_active = not bot_active
    status = "on" if bot_active else "off"
    print(f"\r[toggle] triggerbot is now {status}       ", end="")

def click():
    win32api.mouse_event(win32con.MOUSEEVENTF_LEFTDOWN, 0, 0)
    time.sleep(0.01)
    win32api.mouse_event(win32con.MOUSEEVENTF_LEFTUP, 0, 0)

def main():
    print(f"ready. press {TOGGLE_KEY} to toggle, {QUIT_KEY} to quit")
    keyboard.on_press_key(TOGGLE_KEY, toggle_bot)

    with mss.mss() as sct:
        while True:
            if keyboard.is_pressed(QUIT_KEY): break

            if bot_active:
                img = np.array(sct.grab(monitor))
                hsv = cv2.cvtColor(img[:, :, :3], cv2.COLOR_BGR2HSV)
                mask = cv2.inRange(hsv, LOWER_COLOR, UPPER_COLOR)
                mask = cv2.erode(mask, KERNEL, iterations=1)
                mask = cv2.dilate(mask, KERNEL, iterations=1)

                if cv2.countNonZero(mask) > 0:
                    click()
                    time.sleep(FIRE_DELAY)

            time.sleep(0.001)

if __name__ == "__main__":
    main()
