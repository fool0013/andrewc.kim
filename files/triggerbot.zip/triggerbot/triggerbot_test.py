import ctypes
import random
import statistics
import time
import tkinter as tk

PATCH_HEX = "#e632e6"
PATCH_SIZE = 40
TRIALS = 20
MIN_GAP = 1.2
MAX_GAP = 3.2
SHOW_MS = 900

try:
    ctypes.windll.shcore.SetProcessDpiAwareness(2)
except Exception:
    pass

root = tk.Tk()
root.attributes("-fullscreen", True)
root.attributes("-topmost", True)
root.configure(bg="black")
root.config(cursor="none")
root.update_idletasks()

canvas = tk.Canvas(root, bg="black", highlightthickness=0, borderwidth=0)
canvas.pack(fill="both", expand=True)
root.update_idletasks()

screen_w = root.winfo_screenwidth()
screen_h = root.winfo_screenheight()
target_x = screen_w // 2 - root.winfo_rootx()
target_y = screen_h // 2 - root.winfo_rooty()
half = PATCH_SIZE // 2

canvas.create_rectangle(-10, -10, canvas.winfo_width() + 10, canvas.winfo_height() + 10,
                        fill="black", outline="")
patch = canvas.create_rectangle(target_x - half, target_y - half,
                                target_x + half, target_y + half, fill=PATCH_HEX, outline="")
canvas.itemconfigure(patch, state="hidden")
readout = canvas.create_text(24, 24, anchor="nw", fill="#999", font=("Consolas", 13), text="")

shown_at = None
pending = None
hits = 0
misses = 0
early = 0
times = []


def show(note=""):
    mean = f"{statistics.mean(times) * 1000:.0f} ms" if times else "-"
    canvas.itemconfigure(readout, text=(
        f"trial {hits + misses}/{TRIALS}\n"
        f"hits {hits}   misses {misses}   early clicks {early}\n"
        f"mean reaction {mean}\n\n"
        f"target at screen {screen_w // 2},{screen_h // 2}\n"
        "move the mouse over this window and turn the bot on with v\n"
        "esc quits\n" + note))


def hide():
    global shown_at
    canvas.itemconfigure(patch, state="hidden")
    shown_at = None


def next_round():
    if hits + misses >= TRIALS:
        done()
    else:
        root.after(int(random.uniform(MIN_GAP, MAX_GAP) * 1000), flash)


def flash():
    global shown_at, pending
    canvas.itemconfigure(patch, state="normal")
    canvas.update_idletasks()
    shown_at = time.perf_counter()
    pending = root.after(SHOW_MS, missed)


def missed():
    global misses
    if shown_at is None: return
    misses += 1
    hide()
    show("missed that one")
    next_round()


def clicked(e):
    global hits, early, pending
    if shown_at is None:
        early += 1
        show("clicked with nothing on screen")
        return
    times.append(time.perf_counter() - shown_at)
    hits += 1
    if pending: root.after_cancel(pending)
    pending = None
    hide()
    show("hit")
    next_round()


def done():
    hide()
    print()
    print(f"hits {hits}/{TRIALS}, misses {misses}, early clicks {early}")
    if times:
        ms = sorted(t * 1000 for t in times)
        print(f"reaction: best {ms[0]:.0f} ms, median {statistics.median(ms):.0f} ms, worst {ms[-1]:.0f} ms")
    else:
        print("no hits. is the bot on, and is the cursor over this window?")
    root.after(400, root.destroy)


root.bind("<Button-1>", clicked)
root.bind("<Escape>", lambda e: root.destroy())

print(f"screen {screen_w}x{screen_h}, target drawn at {target_x},{target_y}")
if (root.winfo_rootx(), root.winfo_rooty()) != (0, 0):
    print("warning: window isn't at 0,0, target offset to compensate")
if (screen_w, screen_h) != (1920, 1080):
    print("warning: triggerbot.py is hardcoded to 1920x1080 and watches 960,540")
print("running. esc quits")

show()
next_round()
root.mainloop()
