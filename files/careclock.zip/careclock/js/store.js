import { dateStr, addDays, uid } from './util.js';
import { sanitize } from './sanitize.js';

const KEY = 'careclock.v1';
export const VERSION = 1;

export const defaults = () => ({
  version: VERSION,
  settings: { lang: null, size: 'l', theme: 'auto', sound: true, voice: true, reminders: true, simple: false, pin: '', onboarded: false, weightUnit: 'lb' },
  profile: { name: '', dob: '', blood: '', conditions: '', allergies: '', doctor: '', doctorPhone: '', pharmacy: '', pharmacyPhone: '', contacts: [], notes: '' },
  meds: [],
  log: {},
  prn: [],
  vitals: [],
  appts: [],
  questions: [],
  dismissed: [],
});

export const migrate = (s) => sanitize(s, defaults());

let state = load();
let saveError = false;
const subs = new Set();

function load() {
  try {
    const raw = localStorage.getItem(KEY);
    return raw ? migrate(JSON.parse(raw)) : defaults();
  } catch {
    return defaults();
  }
}

function save() {
  try {
    localStorage.setItem(KEY, JSON.stringify(state));
    saveError = false;
  } catch {
    saveError = true;
  }
}

if (typeof window !== 'undefined') {
  window.addEventListener('storage', (e) => {
    if (e.key !== KEY || !e.newValue) return;
    try {
      state = migrate(JSON.parse(e.newValue));
      subs.forEach((f) => f(state));
    } catch {  }
  });
}

export const store = {
  get: () => state,
  get saveError() { return saveError; },

  update(fn) {
    fn(state);
    save();
    subs.forEach((f) => f(state));
  },
  replace(next) {
    state = migrate(next);
    save();
    subs.forEach((f) => f(state));
  },
  subscribe(f) {
    subs.add(f);
    return () => subs.delete(f);
  },
};

export function markDose(dose, status, when = new Date()) {
  store.update((s) => {
    const day = (s.log[dose.date] ||= {});
    const prev = day[dose.key];
    day[dose.key] = { status, at: when.toISOString() };
    const med = s.meds.find((m) => m.id === dose.med.id);

    if (med && med.quantity != null && med.quantity !== '') {
      const amt = Number(med.amount) || 1;
      if (status === 'taken' && prev?.status !== 'taken') med.quantity = Math.max(0, Number(med.quantity) - amt);
      if (status !== 'taken' && prev?.status === 'taken') med.quantity = Number(med.quantity) + amt;
    }
  });
}

export function undoDose(dose) {
  store.update((s) => {
    const prev = s.log[dose.date]?.[dose.key];
    if (!prev) return;
    delete s.log[dose.date][dose.key];
    const med = s.meds.find((m) => m.id === dose.med.id);
    if (prev.status === 'taken' && med && med.quantity != null && med.quantity !== '') med.quantity = Number(med.quantity) + (Number(med.amount) || 1);
  });
}

export function logPrn(medId) {
  const id = uid();
  store.update((s) => {
    s.prn.push({ id, medId, at: new Date().toISOString() });
    const med = s.meds.find((m) => m.id === medId);
    if (med && med.quantity != null && med.quantity !== '') med.quantity = Math.max(0, Number(med.quantity) - (Number(med.amount) || 1));
  });
  return id;
}

export function undoPrn(id) {
  store.update((s) => {
    const e = s.prn.find((p) => p.id === id);
    if (!e) return;
    s.prn = s.prn.filter((p) => p.id !== id);
    const med = s.meds.find((m) => m.id === e.medId);
    if (med && med.quantity != null && med.quantity !== '') med.quantity = Number(med.quantity) + (Number(med.amount) || 1);
  });
}

export function prune(s, today = dateStr()) {
  const cutoff = addDays(today, -400);
  for (const d of Object.keys(s.log)) if (d < cutoff) delete s.log[d];
  s.prn = s.prn.filter((p) => p.at.slice(0, 10) >= cutoff);
}
