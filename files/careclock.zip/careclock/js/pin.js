const hex = (buf) => [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, '0')).join('');

export async function hashPin(pin, salt = hex(crypto.getRandomValues(new Uint8Array(16)))) {
  const h = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(`careclock:${salt}:${pin}`));
  return `sha256:${salt}:${hex(h)}`;
}

export async function checkPin(pin, stored) {
  const salt = String(stored).split(':')[1];
  if (!salt) return false;
  return (await hashPin(pin, salt)) === stored;
}

const MAX_TRIES = 5;
const KEY = 'careclock.pinlock';
const load = () => {
  try {
    const o = JSON.parse(localStorage.getItem(KEY));
    return { fails: Number(o.fails) || 0, until: Number(o.until) || 0, penalty: Number(o.penalty) || 60000 };
  } catch {
    return { fails: 0, until: 0, penalty: 60000 };
  }
};
let st = load();
const save = () => {
  try { localStorage.setItem(KEY, JSON.stringify(st)); } catch {  }
};

export const lockRemaining = (now = Date.now()) => Math.max(0, Math.ceil((st.until - now) / 1000));

export function recordFail(now = Date.now()) {
  st.fails++;
  if (st.fails >= MAX_TRIES) {
    st.until = now + st.penalty;
    st.penalty = Math.min(st.penalty * 2, 3600000);
    st.fails = 0;
  }
  save();
}

export function recordSuccess() {
  st = { fails: 0, until: 0, penalty: 60000 };
  save();
}
