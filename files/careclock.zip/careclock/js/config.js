export const CONFIG = {
  appName: 'CareClock',

  contactEmail: '',

  repoUrl: 'https://github.com/fool0013/careclock',

  legalUpdated: '2026-10-26',
};
