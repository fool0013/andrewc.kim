import contextlib
import io
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd
import requests

ROOT = Path(__file__).parent
sys.path.insert(0, str(ROOT))

from models.engine import fetch_fundamentals, SECTOR_DEFAULTS, N_YEARS

SCREEN_SIMS = 10_000
RNG_SEED = 42
SLEEP_SECS = 1.0
TARGET_SECTORS = ["Information Technology", "Communication Services"]
WIKI_URL = "https://en.wikipedia.org/wiki/List_of_S%26P_500_companies"

FALLBACK_TICKERS = [
    "AAPL", "MSFT", "NVDA", "GOOGL", "GOOG", "META", "AVGO", "ORCL",
    "CSCO", "CRM", "NFLX", "AMD", "INTC", "QCOM", "TXN", "AMAT",
    "MU", "LRCX", "KLAC", "ADI", "NOW", "PANW", "CDNS", "SNPS",
    "FTNT", "MRVL", "NXPI", "ON", "KEYS", "ZBRA",
]

def get_sector_tickers() :
    print("[screener] Fetching S&P 500 constituent list from Wikipedia ...")
    try:
        headers = {"User-Agent": "Mozilla/5.0 (research purposes)"}
        resp = requests.get(WIKI_URL, headers=headers, timeout=15)
        resp.raise_for_status()

        tables = pd.read_html(io.StringIO(resp.text))
        df = tables[0]

        sector_col = next(
            (c for c in df.columns if "sector" in c.lower()), None
        )
        symbol_col = next(
            (c for c in df.columns
             if c.lower() in ("symbol", "ticker", "symbols")), None
        )

        if sector_col is None or symbol_col is None:
            raise ValueError(
                f"Could not locate Sector/Symbol columns. "
                f"Found: {list(df.columns)}"
            )

        mask = df[sector_col].isin(TARGET_SECTORS)
        tickers = (
            df[mask][symbol_col]
            .str.strip()
            .str.replace(".", "-", regex=False)
            .tolist()
        )

        counts = df[mask][sector_col].value_counts().to_dict()
        for sec, n in counts.items():
            print(f"  {sec}: {n} companies")
        print(f"  Total: {len(tickers)} tickers\n")
        return tickers

    except Exception as exc:
        print(f"  WARNING: Wikipedia scrape failed ({exc})")
        print(f"  Falling back to {len(FALLBACK_TICKERS)}-ticker hardcoded list.\n")
        return FALLBACK_TICKERS

def quick_simulate(fundamentals, n_sims= SCREEN_SIMS) :
    try:
        cp = fundamentals["current_price"]
        shares = fundamentals["shares_outstanding"]
        rev_0 = fundamentals["revenue_0"]

        if cp <= 0 or shares <= 0 or rev_0 <= 0:
            return None

        rng = np.random.default_rng(RNG_SEED)

        rev_mean = fundamentals["hist_rev_growth_mean"]
        rev_std = fundamentals["hist_rev_growth_std"]
        fcf_mu = fundamentals["hist_fcf_margin_mean"]
        fcf_sigma = fundamentals["hist_fcf_margin_std"]
        wacc_base = fundamentals["wacc"]
        tg = fundamentals["terminal_growth"]
        net_debt = fundamentals["net_debt"]

        wacc_sim = np.clip(
            wacc_base + rng.normal(0.0, 0.005, n_sims),
            0.05, 0.25,
        )

        growth = np.clip(
            rng.normal(rev_mean, rev_std, (n_sims, N_YEARS)),
            -0.60, 2.00,
        )
        revenues = rev_0 * np.cumprod(1.0 + growth, axis=1)

        fcf_margins = np.clip(
            rng.normal(fcf_mu, fcf_sigma, (n_sims, N_YEARS)),
            0.01, 0.70,
        )

        fcf = revenues * fcf_margins
        t = np.arange(1, N_YEARS + 1, dtype=np.float64)
        discount = 1.0 / (1.0 + wacc_sim[:, np.newaxis]) ** t[np.newaxis, :]
        pv_fcf = (fcf * discount).sum(axis=1)

        tg_sim = np.clip(
            rng.normal(tg, 0.005, n_sims),
            0.010, wacc_sim - 0.005,
        )
        pv_tv = (fcf[:, -1] * (1.0 + tg_sim) / (wacc_sim - tg_sim)) \
                / (1.0 + wacc_sim) ** N_YEARS

        price = (pv_fcf + pv_tv - net_debt) / shares

        lo, hi = np.percentile(price, [0.5, 99.5])
        price = np.clip(price, lo, hi)

        median = float(np.median(price))
        p10 = float(np.percentile(price, 10))
        p90 = float(np.percentile(price, 90))

        return {
            "current_price": cp,
            "target_price": median,
            "upside_pct": (median - cp) / cp * 100,
            "drawdown_pct": (p10 - cp) / cp * 100,
            "p90_upside_pct": (p90 - cp) / cp * 100,
            "wacc": wacc_base,
            "rev_growth": rev_mean * 100,
            "fcf_margin": fcf_mu * 100,
            "prob_above": float(np.mean(price > cp) * 100),
        }

    except Exception:
        return None

def run_screen(tickers) :
    total = len(tickers)
    results = []

    print(f"[screener] Screening {total} stocks  |  "
          f"{SCREEN_SIMS:,} Monte Carlo paths each")
    eta = total * (SLEEP_SECS + 1.5)
    print(f"           Estimated runtime: ~{eta/60:.1f} min  "
          f"({SLEEP_SECS}s rate-limit delay between pulls)\n")

    bar_w = 28

    for i, ticker in enumerate(tickers, 1):
        pct_done = i / total
        filled = int(bar_w * pct_done)
        bar = "#" * filled + "." * (bar_w - filled)
        prefix   = f"  [{i:>3}/{total}]  [{bar}]  {ticker:<6}"

        try:
            buf = io.StringIO()
            with contextlib.redirect_stdout(buf):
                fundamentals = fetch_fundamentals(ticker)

            result = quick_simulate(fundamentals)

            if result is None:
                print(f"{prefix}  SKIP  (insufficient data)")
            else:
                u = result["upside_pct"]
                d = result["drawdown_pct"]
                up = f"{'+' if u >= 0 else ''}{u:.1f}%"
                dn = f"{d:.1f}%"
                print(
                    f"{prefix}  "
                    f"${result['current_price']:>8.2f} -> "
                    f"${result['target_price']:>8.2f}  "
                    f"upside={up:>7}  "
                    f"VaR={dn:>7}"
                )
                results.append({"ticker": ticker, **result})

        except KeyboardInterrupt:
            print("\n[screener] Interrupted by user , printing partial results.")
            break
        except Exception as exc:
            print(f"{prefix}  WARN  ({type(exc).__name__}: {str(exc)[:55]})")

        if i < total:
            time.sleep(SLEEP_SECS)

    return results

def _signal(upside) :
    if upside >= 20: return "STRONG BUY"
    if upside >= 10: return "BUY"
    if upside >= 3: return "BUY"
    if upside >= -5: return "HOLD"
    if upside >=-15: return "SELL"
    return "STRONG SELL"

def print_ranking_table(results):
    if not results:
        print("[screener] No valid results to display.")
        return

    ranked = sorted(results, key=lambda r: r["upside_pct"], reverse=True)

    cols = [
        ("Rank", 5),
        ("Ticker", 7),
        ("Curr $", 10),
        ("Target $", 10),
        ("Upside %", 10),
        ("VaR P10 %", 11),
        ("P(>Mkt)", 9),
        ("Rev Gr%", 9),
        ("FCF Mg%", 9),
        ("WACC", 7),
        ("Signal", 12),
    ]
    total_w = sum(w for _, w in cols) + len(cols) + 2

    SEP = "=" * total_w
    DASH = "-" * total_w
    MSEP = "~" * total_w

    def fmt_row(values):
        parts = []
        for val, (_, w) in zip(values, cols):
            parts.append(str(val).rjust(w))
        return " " + " ".join(parts)

    print(f"\n\n{SEP}")
    print(
        f"  S&P 500 IT + COMM SERVICES SCREENER"
        f"   |   {len(ranked)} stocks ranked   "
        f"|   {SCREEN_SIMS:,} Monte Carlo paths"
    )
    print(SEP)

    print(fmt_row([h for h, _ in cols]))
    print(DASH)

    buys = 0
    holds = 0
    sells = 0

    for rank, r in enumerate(ranked, 1):
        sig = _signal(r["upside_pct"])
        if "BUY" in sig: buys += 1
        elif "HOLD" == sig: holds += 1
        else: sells += 1

        u_str = f"{'+' if r['upside_pct'] >= 0 else ''}{r['upside_pct']:.1f}%"
        d_str = f"{r['drawdown_pct']:.1f}%"
        p_str = f"{r['prob_above']:.0f}%"

        row = fmt_row([
            rank,
            r["ticker"],
            f"${r['current_price']:,.2f}",
            f"${r['target_price']:,.2f}",
            u_str,
            d_str,
            p_str,
            f"{r['rev_growth']:.1f}%",
            f"{r['fcf_margin']:.1f}%",
            f"{r['wacc']*100:.1f}%",
            sig,
        ])
        print(row)

        if rank % 10 == 0 and rank < len(ranked):
            print(MSEP)

    print(SEP)

    print(
        f"\n  Signal summary:  "
        f"BUY/STRONG BUY: {buys}   "
        f"HOLD: {holds}   "
        f"SELL/STRONG SELL: {sells}"
    )

    print(f"\n  TOP CANDIDATES FOR FULL 100k-PATH ANALYSIS:")
    for n, r in enumerate(ranked[:3], 1):
        sig = _signal(r["upside_pct"])
        print(
            f"    {n}. {r['ticker']:<6}  "
            f"Target ${r['target_price']:.2f}  |  "
            f"Upside {'+' if r['upside_pct'] >= 0 else ''}{r['upside_pct']:.1f}%  |  "
            f"VaR {r['drawdown_pct']:.1f}%  |  {sig}"
        )

    top = ranked[0]
    print(
        f"\n  >> To run full analysis: "
        f"set TICKER = '{top['ticker']}' in models/engine.py, "
        f"then run: python run.py\n"
    )

if __name__ == "__main__":
    t0 = time.perf_counter()

    tickers = get_sector_tickers()
    results = run_screen(tickers)
    print_ranking_table(results)

    elapsed = time.perf_counter() - t0
    mins, secs = divmod(int(elapsed), 60)
    print(f"  Total screen time: {mins}m {secs}s\n")
