TICKER = "NVDA"

import json
import warnings
from pathlib import Path

import numpy as np
import pandas as pd
import yfinance as yf

warnings.filterwarnings("ignore")

ROOT = Path(__file__).parent.parent
DATA_DIR = ROOT / "data"
DATA_DIR.mkdir(exist_ok=True)

SECTOR_DEFAULTS = {
    "revenue_growth": 0.12,
    "revenue_growth_std": 0.05,
    "fcf_margin": 0.18,
    "fcf_margin_std": 0.04,
    "beta": 1.25,
    "cost_of_debt": 0.055,
    "terminal_growth": 0.03,
    "risk_free_rate": 0.045,
    "equity_risk_prem": 0.055,
}

N_SIMS = 100_000
N_YEARS = 5
RNG_SEED = 42

def first_value(series, default):
    if series is None: return default
    vals = series.dropna()
    return float(vals.iloc[0]) if len(vals) > 0 else default

def find_row(df, *names):
    if df is None or df.empty: return None
    for name in names:
        if name in df.index: return df.loc[name]
    return None

def fetch_fundamentals(ticker):
    stock = yf.Ticker(ticker)
    info = {}
    try:
        info = stock.info or {}
    except Exception:
        pass

    price = info.get("currentPrice") or info.get("regularMarketPrice") or info.get("previousClose") or 0.0
    shares = info.get("sharesOutstanding") or info.get("impliedSharesOutstanding") or 1e9
    mcap = info.get("marketCap") or float(price) * float(shares)
    beta = float(info.get("beta") or SECTOR_DEFAULTS["beta"])

    inc = None
    try:
        inc = stock.financials
        if inc is None or inc.empty: inc = stock.income_stmt
    except Exception:
        pass
    rev_hist = find_row(inc, "Total Revenue", "Revenue")
    ebit_hist = find_row(inc, "EBIT", "Operating Income", "Ebit")
    interest_hist = find_row(inc, "Interest Expense", "Interest Expense Non Operating")
    tax_hist = find_row(inc, "Tax Rate For Calcs", "Effective Tax Rate")

    cf = None
    try:
        cf = stock.cashflow
        if cf is None or cf.empty: cf = stock.cash_flow
    except Exception:
        pass
    fcf_hist = find_row(cf, "Free Cash Flow")
    da_hist = find_row(cf, "Depreciation And Amortization", "Depreciation Amortization Depletion", "Depreciation")

    bs = None
    try:
        bs = stock.balance_sheet
        if bs is None or bs.empty: bs = stock.quarterly_balance_sheet
    except Exception:
        pass
    net_debt_hist = find_row(bs, "Net Debt")
    cash_hist = find_row(bs, "Cash Cash Equivalents And Short Term Investments", "Cash And Cash Equivalents")
    debt_hist = find_row(bs, "Long Term Debt", "Long Term Debt And Capital Lease Obligation", "Total Debt")

    rev0 = first_value(rev_hist, 1e10)
    fcf0 = first_value(fcf_hist, rev0 * SECTOR_DEFAULTS["fcf_margin"])
    da0 = abs(first_value(da_hist, rev0 * 0.04))

    if net_debt_hist is not None:
        net_debt = first_value(net_debt_hist, 0.0)
    else:
        cash = max(first_value(cash_hist, 0.0), 0.0)
        ltd = max(first_value(debt_hist, 0.0), 0.0)
        net_debt = ltd - cash

    tax = 0.21
    if tax_hist is not None:
        vals = tax_hist.dropna()
        if len(vals) > 0:
            rate = float(vals.iloc[0])
            if 0.01 < rate < 0.60: tax = rate

    if rev_hist is not None and len(rev_hist.dropna()) >= 3:
        revs = rev_hist.dropna().values[::-1]
        growth = np.diff(revs) / np.abs(revs[:-1])
        growth_mean = float(np.mean(growth))
        growth_std = float(np.std(growth))
    else:
        growth_mean = SECTOR_DEFAULTS["revenue_growth"]
        growth_std = SECTOR_DEFAULTS["revenue_growth_std"]

    if fcf_hist is not None and rev_hist is not None:
        fcf_vals = fcf_hist.dropna()
        rev_vals = rev_hist.dropna()
        years = fcf_vals.index.intersection(rev_vals.index)
        if len(years) >= 2:
            margins = (fcf_vals[years] / rev_vals[years]).values
            margin_mean = float(np.mean(margins))
            margin_std = float(np.std(margins))
        else:
            margin_mean = fcf0 / rev0
            margin_std = SECTOR_DEFAULTS["fcf_margin_std"]
    else:
        margin_mean = fcf0 / rev0 if rev0 > 0 else SECTOR_DEFAULTS["fcf_margin"]
        margin_std = SECTOR_DEFAULTS["fcf_margin_std"]
    margin_mean = float(np.clip(margin_mean, -0.05, 0.55))
    margin_std = max(margin_std, 0.02)

    op_margin = 0.0
    if ebit_hist is not None and rev_hist is not None:
        ebit_vals = ebit_hist.dropna()
        op_revs = rev_hist.dropna()
        op_years = ebit_vals.index.intersection(op_revs.index)
        if len(op_years) >= 1: op_margin = float(np.mean((ebit_vals[op_years] / op_revs[op_years]).values))
    if op_margin == 0.0:
        ebit0 = first_value(ebit_hist, rev0 * 0.20)
        op_margin = ebit0 / rev0 if rev0 > 0 else 0.20

    rf = SECTOR_DEFAULTS["risk_free_rate"]
    erp = SECTOR_DEFAULTS["equity_risk_prem"]
    cost_equity = rf + beta * erp

    debt = max(first_value(debt_hist, 0.0), 0.0)
    cost_debt = SECTOR_DEFAULTS["cost_of_debt"]
    if debt > 1e6 and interest_hist is not None:
        interest = abs(first_value(interest_hist, 0.0))
        if interest > 0: cost_debt = float(np.clip(interest / debt, 0.02, 0.15))

    capital = mcap + debt
    w_equity = mcap / capital if capital > 0 else 1.0
    w_debt = debt / capital if capital > 0 else 0.0
    wacc = w_equity * cost_equity + w_debt * cost_debt * (1 - tax)
    wacc = float(np.clip(wacc, 0.06, 0.20))

    fund = {
        "ticker": ticker,
        "current_price": float(price),
        "shares_outstanding": float(shares),
        "market_cap": float(mcap),
        "revenue_0": rev0,
        "fcf_0": fcf0,
        "da_0": da0,
        "net_debt": net_debt,
        "tax_rate": tax,
        "hist_rev_growth_mean": growth_mean,
        "hist_rev_growth_std": growth_std,
        "hist_fcf_margin_mean": margin_mean,
        "hist_fcf_margin_std": margin_std,
        "hist_op_margin_mean": op_margin,
        "wacc": wacc,
        "terminal_growth": SECTOR_DEFAULTS["terminal_growth"],
        "beta": beta,
        "cost_of_equity": cost_equity,
        "cost_of_debt": cost_debt,
    }
    with open(DATA_DIR / f"{ticker}_fundamentals.json", "w") as fh:
        json.dump(fund, fh, indent=2)

    print(f"{ticker}: revenue ${rev0 / 1e9:.1f}b, fcf ${fcf0 / 1e9:.1f}b ({fcf0 / rev0:.1%} margin)")
    print(f"fcf margin avg {margin_mean:.1%} (sd {margin_std:.1%}), net debt ${net_debt / 1e9:.1f}b")
    print(f"wacc {wacc:.2%}, beta {beta:.2f}, price ${price:.2f}")
    return fund

def run_simulation(fund, scenario="base"):
    rng = np.random.default_rng(RNG_SEED)
    shape = (N_SIMS, N_YEARS)

    if scenario == "inflation":
        wacc_shock = rng.uniform(0.02, 0.04, N_SIMS)
        margin_shock = rng.uniform(-0.06, -0.03, N_SIMS)
    elif scenario == "demand":
        wacc_shock = rng.uniform(0, 0.01, N_SIMS)
        margin_shock = rng.uniform(-0.025, 0, N_SIMS)
    else:
        wacc_shock = rng.normal(0, 0.005, N_SIMS)
        margin_shock = np.zeros(N_SIMS)
    wacc = np.clip(fund["wacc"] + wacc_shock, 0.05, 0.25)

    growth = rng.normal(fund["hist_rev_growth_mean"], fund["hist_rev_growth_std"], shape)
    if scenario == "demand":
        growth[:, 0] += rng.uniform(-0.3, -0.1, N_SIMS)
        growth[:, 1] += rng.uniform(-0.2, -0.05, N_SIMS)
    revenue = fund["revenue_0"] * np.cumprod(1 + np.clip(growth, -0.6, 2), axis=1)

    margin = rng.normal(fund["hist_fcf_margin_mean"], fund["hist_fcf_margin_std"], shape)
    fcf = revenue * np.clip(margin + margin_shock[:, None], 0.01, 0.7)

    years = np.arange(1, N_YEARS + 1)
    pv_fcf = (fcf / (1 + wacc[:, None]) ** years).sum(axis=1)

    tg = np.clip(rng.normal(fund["terminal_growth"], 0.005, N_SIMS), 0.01, wacc - 0.005)
    tv = fcf[:, -1] * (1 + tg) / (wacc - tg)
    pv_tv = tv / (1 + wacc) ** N_YEARS

    price = (pv_fcf + pv_tv - fund["net_debt"]) / fund["shares_outstanding"]
    lo, hi = np.percentile(price, [0.5, 99.5])
    return np.clip(price, lo, hi).astype(np.float32)

def run_all_scenarios(fund):
    ticker = fund["ticker"]
    cur_price = fund["current_price"]
    labels = {"base": "Base Case", "inflation": "Inflationary Shock", "demand": "Demand Contraction"}

    results = {}
    for key, label in labels.items():
        prices = run_simulation(fund, scenario=key)
        stats = {
            "label": label,
            "prices": prices,
            "mean": float(np.mean(prices)),
            "median": float(np.median(prices)),
            "std": float(np.std(prices)),
        }
        for p in [5, 10, 25, 75, 90, 95]:
            stats[f"p{p}"] = float(np.percentile(prices, p))
        results[key] = stats

        above = float(np.mean(prices > cur_price) * 100)
        print(f"{key}: median ${stats['median']:.2f}, {above:.1f}% above market")
        pd.Series(prices, name="simulated_price").to_csv(DATA_DIR / f"{ticker}_{key}_prices.csv", index=False)

    base_med = results["base"]["median"]
    inf_med = results["inflation"]["median"]
    dem_med = results["demand"]["median"]
    summary = {
        "ticker": ticker,
        "current_price": cur_price,
        "base_median": base_med,
        "base_mean": results["base"]["mean"],
        "base_std": results["base"]["std"],
        "inflation_median": inf_med,
        "demand_median": dem_med,
        "upside_pct": (base_med - cur_price) / cur_price * 100 if cur_price else 0.0,
        "inflation_drawdown_pct": (inf_med - base_med) / abs(base_med) * 100,
        "demand_drawdown_pct": (dem_med - base_med) / abs(base_med) * 100,
        "p10_base": results["base"]["p10"],
        "p90_base": results["base"]["p90"],
        "p25_base": results["base"]["p25"],
        "p75_base": results["base"]["p75"],
        "p10_inflation": results["inflation"]["p10"],
        "p90_inflation": results["inflation"]["p90"],
        "p10_demand": results["demand"]["p10"],
        "p90_demand": results["demand"]["p90"],
        "prob_above_market_base": float(np.mean(results["base"]["prices"] > cur_price) * 100),
        "prob_above_market_inf": float(np.mean(results["inflation"]["prices"] > cur_price) * 100),
        "prob_above_market_dem": float(np.mean(results["demand"]["prices"] > cur_price) * 100),
        "wacc": fund["wacc"],
        "beta": fund["beta"],
        "tax_rate": fund["tax_rate"],
        "revenue_0": fund["revenue_0"],
        "fcf_0": fund["fcf_0"],
        "hist_rev_growth": fund["hist_rev_growth_mean"],
        "hist_fcf_margin": fund["hist_fcf_margin_mean"],
        "hist_op_margin": fund.get("hist_op_margin_mean", 0.0),
        "net_debt": fund["net_debt"],
        "n_sims": N_SIMS,
        "n_years": N_YEARS,
    }
    with open(DATA_DIR / f"{ticker}_summary.json", "w") as fh:
        json.dump(summary, fh, indent=2)

    print(f"market ${cur_price:.2f}, base case {summary['upside_pct']:+.1f}%")
    return results, summary

if __name__ == "__main__":
    fund = fetch_fundamentals(TICKER)
    run_all_scenarios(fund)
