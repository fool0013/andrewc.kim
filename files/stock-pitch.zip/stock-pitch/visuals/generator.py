import json
from pathlib import Path

import matplotlib.patches as mpatches
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
import numpy as np
import pandas as pd
import seaborn as sns

ROOT = Path(__file__).parent.parent
DATA_DIR = ROOT / "data"
VIS_DIR = ROOT / "visuals"
VIS_DIR.mkdir(exist_ok=True)

DARK_BG = "#0D1117"
PANEL_BG = "#161B22"
GRID_CLR = "#21262D"
TEXT_CLR = "#E6EDF3"
ACCENT = "#58A6FF"
GREEN = "#3FB950"
RED = "#F85149"
AMBER = "#D29922"
MUTED = "#8B949E"

PALETTE = {"base": ACCENT, "inflation": RED, "demand": AMBER}

plt.rcParams.update({
    "figure.facecolor": DARK_BG,
    "axes.facecolor": PANEL_BG,
    "axes.edgecolor": GRID_CLR,
    "axes.labelcolor": TEXT_CLR,
    "xtick.color": MUTED,
    "ytick.color": MUTED,
    "text.color": TEXT_CLR,
    "grid.color": GRID_CLR,
    "grid.linewidth": 0.5,
    "font.family": "sans-serif",
    "font.size": 11,
    "axes.titlesize": 13,
    "axes.titleweight": "bold",
    "legend.facecolor": PANEL_BG,
    "legend.edgecolor": GRID_CLR,
    "legend.labelcolor": TEXT_CLR,
})

def _load(ticker) :
    with open(DATA_DIR / f"{ticker}_summary.json") as fh:
        summary = json.load(fh)
    prices = {
        sc: pd.read_csv(DATA_DIR / f"{ticker}_{sc}_prices.csv")["simulated_price"].values
        for sc in ("base", "inflation", "demand")
    }
    return summary, prices

def _vline(ax, x, color, ls= "--", lw= 1.8, label= ""):
    ax.axvline(x, color=color, linestyle=ls, linewidth=lw, alpha=0.90, zorder=5,
               label=label if label else None)
    ax.text(x, 0.97, f"${x:,.0f}", color=color,
            ha="center", va="top", fontsize=8.5, fontweight="bold",
            transform=ax.get_xaxis_transform(), zorder=6)

def _dollar_fmt(ax, axis= "both"):
    fmt = mticker.FuncFormatter(lambda v, _: f"${v:,.0f}")
    if axis in ("x", "both"):
        ax.xaxis.set_major_formatter(fmt)
    if axis in ("y", "both"):
        ax.yaxis.set_major_formatter(fmt)

def plot_price_distribution(ticker):
    summary, prices = _load(ticker)

    cp = summary["current_price"]
    bm = summary["base_median"]
    p10 = summary["p10_base"]
    p90 = summary["p90_base"]
    upside = summary["upside_pct"]
    n_sims = summary["n_sims"]
    prob_b = summary["prob_above_market_base"]
    prob_i = summary["prob_above_market_inf"]
    prob_d = summary["prob_above_market_dem"]

    fig, ax = plt.subplots(figsize=(15, 7))
    fig.patch.set_facecolor(DARK_BG)
    ax.set_facecolor(PANEL_BG)

    _prob_keys = {
        "base": "prob_above_market_base",
        "inflation": "prob_above_market_inf",
        "demand": "prob_above_market_dem",
    }
    scene_meta = [
        ("base", "Base Case", ACCENT),
        ("inflation", "Inflationary Shock", RED),
        ("demand", "Demand Contraction", AMBER),
    ]
    for key, label, col in scene_meta:
        pct = summary.get(_prob_keys[key], 0.0)
        sns.kdeplot(
            prices[key], ax=ax,
            color=col, linewidth=2.4,
            label=f"{label}  [P(>mkt) = {pct:.0f}%]",
            fill=True, alpha=0.12, cut=0,
        )

    ax.axvspan(p10, p90, alpha=0.06, color=ACCENT, zorder=1,
               label=f"Base 80% CI  (${p10:,.0f} - ${p90:,.0f})")

    _vline(ax, cp,  AMBER, ls="--", lw=2.0, label=f"Current Market Price  ${cp:,.2f}")
    _vline(ax, bm,  GREEN, ls="-",  lw=2.0, label=f"Base Median  ${bm:,.2f}  ({upside:+.1f}%)")
    _vline(ax, p10, MUTED, ls=":",  lw=1.4, label=f"P10 VaR  ${p10:,.0f}")
    _vline(ax, p90, MUTED, ls=":",  lw=1.4, label=f"P90  ${p90:,.0f}")

    direction = "UPSIDE" if upside > 0 else "DOWNSIDE"
    ax.set_title(
        f"{ticker}  -  Macro-Shock Monte Carlo Valuation   "
        f"|   {n_sims:,} Simulations   "
        f"|   Base Median {upside:+.1f}% {direction}",
        pad=18, color=TEXT_CLR,
    )
    ax.set_xlabel("Simulated Intrinsic Price per Share (USD)", labelpad=12)
    ax.set_ylabel("Probability Density", labelpad=12)
    _dollar_fmt(ax, "x")
    ax.grid(True, axis="x", alpha=0.35, zorder=0)
    ax.set_yticks([])
    ax.legend(loc="upper right", fontsize=9.5, framealpha=0.75,
              handlelength=1.6, borderpad=0.8)

    ann_txt = (
        f"P(Base > Mkt):  {prob_b:.0f}%\n"
        f"P(Infl > Mkt):  {prob_i:.0f}%\n"
        f"P(Dem  > Mkt):  {prob_d:.0f}%"
    )
    ax.text(0.013, 0.97, ann_txt, transform=ax.transAxes,
            va="top", ha="left", fontsize=9.5, color=TEXT_CLR,
            bbox=dict(boxstyle="round,pad=0.5", facecolor=PANEL_BG,
                      edgecolor=GRID_CLR, alpha=0.85))

    fig.text(0.99, 0.01,
             f"Macro-Shock Monte Carlo Engine  -  {ticker}  -  Quant Pitch",
             ha="right", va="bottom", color=MUTED, fontsize=8, alpha=0.55)

    plt.tight_layout(pad=1.8)
    out = VIS_DIR / f"{ticker}_price_distribution.png"
    plt.savefig(out, dpi=180, bbox_inches="tight", facecolor=DARK_BG)
    plt.close()
    print(f"[visuals] Saved -> {out.name}")

def plot_macro_impact(ticker):
    summary, prices = _load(ticker)

    cp = summary["current_price"]
    bm = summary["base_median"]
    inf_m = summary["inflation_median"]
    dem_m = summary["demand_median"]
    inf_d = summary["inflation_drawdown_pct"]
    dem_d = summary["demand_drawdown_pct"]

    fig, (ax_wf, ax_box) = plt.subplots(
        1, 2, figsize=(17, 8),
        gridspec_kw={"width_ratios": [1.2, 1], "wspace": 0.08},
    )
    fig.patch.set_facecolor(DARK_BG)
    for ax in (ax_wf, ax_box):
        ax.set_facecolor(PANEL_BG)

    worst = min(inf_m, dem_m)

    wf_x = [0, 1, 2, 3]
    wf_bottom = [0, bm, bm, 0]
    wf_heights = [bm, inf_m-bm, dem_m-bm, worst]
    wf_colors = [GREEN,
                  RED if inf_m < bm else GREEN,
                  AMBER if dem_m < bm else GREEN,
                  RED if worst < cp else GREEN]
    wf_labels = ["Base\nMedian", "Inflation\nImpact", "Demand\nImpact", "Worst-Case\nFloor"]

    bars = ax_wf.bar(
        wf_x, wf_heights, bottom=wf_bottom,
        color=wf_colors, width=0.52,
        alpha=0.82, edgecolor=DARK_BG, linewidth=1.5, zorder=3,
    )

    connector_pairs = [(0, 1, bm), (0, 2, bm)]
    for x_from, x_to, y_val in connector_pairs:
        ax_wf.plot([x_from + 0.26, x_to - 0.26], [y_val, y_val],
                   color=MUTED, linewidth=1.0, linestyle=":", alpha=0.6, zorder=4)

    for bar, bot, h, lbl in zip(bars, wf_bottom, wf_heights, wf_labels):
        final = bot + h
        col = TEXT_CLR
        label_y = bot + h / 2 if abs(h) > bm * 0.05 else final + bm * 0.01
        pct_str = f" ({(final-bm)/bm*100:+.1f}%)" if lbl != "Base\nMedian" else ""
        ax_wf.text(bar.get_x() + bar.get_width() / 2, label_y,
                   f"${final:,.0f}{pct_str}",
                   ha="center", va="center", color=col,
                   fontsize=10, fontweight="bold", zorder=5)

    ax_wf.axhline(cp, color=AMBER, linestyle="--", linewidth=1.8, alpha=0.85, zorder=6,
                  label=f"Current Market Price  ${cp:,.2f}")

    ax_wf.set_xticks(wf_x)
    ax_wf.set_xticklabels(wf_labels, fontsize=11)
    ax_wf.set_title(f"{ticker}  -  Macro Scenario Value Waterfall", pad=16)
    ax_wf.set_ylabel("Intrinsic Price per Share (USD)", labelpad=12)
    _dollar_fmt(ax_wf, "y")
    ax_wf.grid(True, axis="y", alpha=0.35, zorder=0)
    ax_wf.legend(fontsize=10, loc="lower right", framealpha=0.75)

    ax_wf.annotate(
        f"Inflation wipes\n${abs(inf_m-bm):,.0f} ({abs(inf_d):.1f}%) vs base",
        xy=(1, inf_m), xytext=(1.55, inf_m * 0.97),
        fontsize=9, color=RED, ha="left",
        arrowprops=dict(arrowstyle="->", color=RED, lw=1.2),
    )
    ax_wf.annotate(
        f"Demand wipes\n${abs(dem_m-bm):,.0f} ({abs(dem_d):.1f}%) vs base",
        xy=(2, dem_m), xytext=(2.35, dem_m * 1.03),
        fontsize=9, color=AMBER, ha="left",
        arrowprops=dict(arrowstyle="->", color=AMBER, lw=1.2),
    )

    scene_order = [("base", "Base\nCase", ACCENT),
                   ("inflation", "Inflation\nShock", RED),
                   ("demand", "Demand\nContraction", AMBER)]

    for i, (key, lbl, col) in enumerate(scene_order):
        p = prices[key]
        q = np.percentile(p, [10, 25, 50, 75, 90])
        p10v, p25v, p50v, p75v, p90v = q

        w = 0.35
        ax_box.bar(i, p75v - p25v, bottom=p25v,
                   color=col, alpha=0.45, width=w * 2,
                   edgecolor=col, linewidth=1.8, zorder=3)
        ax_box.hlines(p50v, i - w, i + w, colors=col, linewidth=3.5, zorder=5)
        ax_box.vlines(i, p10v, p25v, colors=col, linewidth=1.5, linestyle=":", alpha=0.7, zorder=4)
        ax_box.vlines(i, p75v, p90v, colors=col, linewidth=1.5, linestyle=":", alpha=0.7, zorder=4)
        cap_w = 0.12
        for cap_y in (p10v, p90v):
            ax_box.hlines(cap_y, i - cap_w, i + cap_w, colors=col, linewidth=1.5, alpha=0.7, zorder=4)

        ax_box.text(i + w + 0.04, p50v, f"  ${p50v:,.0f}",
                    va="center", ha="left", color=col,
                    fontsize=10.5, fontweight="bold", zorder=6)
        ax_box.text(i, p90v, f"P90: ${p90v:,.0f}",
                    va="bottom", ha="center", color=col, fontsize=8, alpha=0.8)
        ax_box.text(i, p10v, f"P10: ${p10v:,.0f}",
                    va="top", ha="center", color=col, fontsize=8, alpha=0.8)

    ax_box.axhline(cp, color=AMBER, linestyle="--", linewidth=1.8, alpha=0.85,
                   label=f"Current Market Price  ${cp:,.2f}", zorder=6)

    ax_box.set_xticks(range(3))
    ax_box.set_xticklabels([s[1] for s in scene_order], fontsize=11)
    ax_box.set_title(f"{ticker}  -  P10 / P50 / P90 by Scenario", pad=16)
    ax_box.set_ylabel("Simulated Price per Share (USD)", labelpad=12)
    _dollar_fmt(ax_box, "y")
    ax_box.grid(True, axis="y", alpha=0.35, zorder=0)
    ax_box.legend(fontsize=10, loc="lower right", framealpha=0.75)
    ax_box.set_xlim(-0.65, 2.65)

    fig.text(0.99, 0.01,
             f"Macro-Shock Monte Carlo Engine  -  {ticker}  -  Quant Pitch",
             ha="right", va="bottom", color=MUTED, fontsize=8, alpha=0.55)

    plt.tight_layout(pad=1.8)
    out = VIS_DIR / f"{ticker}_macro_impact.png"
    plt.savefig(out, dpi=180, bbox_inches="tight", facecolor=DARK_BG)
    plt.close()
    print(f"[visuals] Saved -> {out.name}")

def generate_all(ticker):
    print(f"[visuals] Rendering charts for {ticker} ...")
    plot_price_distribution(ticker)
    plot_macro_impact(ticker)
    print("[visuals] All charts complete.")

if __name__ == "__main__":
    import sys
    sys.path.insert(0, str(ROOT))
    from models.engine import TICKER
    generate_all(TICKER)
