import sys
import time
from pathlib import Path

ROOT = Path(__file__).parent
sys.path.insert(0, str(ROOT))

from models.engine import TICKER, fetch_fundamentals, run_all_scenarios
from visuals.generator import generate_all

def main():
    start = time.perf_counter()

    fund = fetch_fundamentals(TICKER)
    results, summary = run_all_scenarios(fund)
    generate_all(TICKER)

    upside = summary["upside_pct"]
    elapsed = time.perf_counter() - start
    print(f"wrote visuals/{TICKER}_*.png")
    print(f"{TICKER}: {rating(upside)} ({upside:+.1f}%), done in {elapsed:.1f}s")

def rating(upside):
    if upside >= 25: return "STRONG BUY"
    if upside >= 3: return "BUY"
    if upside >= -5: return "HOLD"
    if upside >= -15: return "SELL"
    return "STRONG SELL"

if __name__ == "__main__":
    main()
