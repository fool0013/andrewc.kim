#include <iostream>
#include <vector>
using namespace std;

string solve(int N, int R, vector<int> A) {
	int c = 2, nxt = 0;
	for (int t : A) {
		while (c < 2 && nxt <= t) c++, nxt += R;
		if (!c) return "NO";
		if (c == 2) nxt = t + R;
		c--;
	}
	return "YES";
}

int main() {
	ios::sync_with_stdio(0);
	cin.tie(0);
	int T; cin >> T;
	while (T--) {
		int N, R; cin >> N >> R;
		vector<int> A(N);
		for (int i = 0; i < N; i++) {
			cin >> A[i];
		}

		cout << solve(N, R, A) << "\n";
	}
}
