#include <iostream>
#include <vector>
using namespace std;

void solve(int N, int K, vector<char>& A) {
    string g(N, '?');
    for (char x : A) {
        for (char &c : g) if (c == '?') c = x;
        cout << g << endl;
        string r; cin >> r;
        if (r == "CORRECT") return;
        for (int i = 0; i < N; i++) if (r[i] == '_') g[i] = '?';
    }
}

string read_string() {
    string s; cin >> s;
    return s;
}

string print_guess(string guess) {
    cout << guess << endl;
}

int main() {
    ios::sync_with_stdio(0);
    cin.tie(0);
    int T;
    cin >> T;

    for (int i = 0; i < T; i++) {
        int N, K;
        cin >> N >> K;

        vector<char> A(K);
        for (int j = 0; j < K; j++) {
            cin >> A[j];
        }

        solve(N, K, A);
    }

    return 0;
}
