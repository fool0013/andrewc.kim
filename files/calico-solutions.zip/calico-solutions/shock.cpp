#include <iostream>
#include <vector>
#include <numeric>
#include <cmath>
using namespace std;

vector<vector<int>> solve(int N, int M, int Q, vector<int>& X, vector<int>& Y, vector<int>& P) {
    vector<vector<int>> a(N, vector<int>(M, 0));
    vector<int> nx(N * (M + 1));
    iota(nx.begin(), nx.end(), 0);
    auto find = [&](int x) { while (nx[x] != x) x = nx[x] = nx[nx[x]]; return x; };
    for (int i = Q - 1; i >= 0; i--) {
        int r0 = X[i], c0 = Y[i], p = P[i];
        for (int r = r0 - p; r <= r0 + p; r++) {
            int v = p * p - (r - r0) * (r - r0), w = sqrt(v), b = r * (M + 1);
            for (int c = find(b + c0 - w); c - b <= c0 + w; c = find(c))
                a[r][c - b] = v - (c - b - c0) * (c - b - c0) + 1, nx[c] = c + 1;
        }
    }
    return a;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int T; cin >> T;
    while (T--) {
        int N, M, Q; cin >> N >> M >> Q;
        vector<int> X(Q), Y(Q), P(Q);
        for (int i = 0; i < Q; i++) {
            cin >> X[i] >> Y[i] >> P[i];
        }
        vector<vector<int>> answer = solve(N, M, Q, X, Y, P);
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < M; j++) {
                if (j > 0) cout << ' ';
                cout << answer[i][j];
            }
            cout << '\n';
        }
    }
    return 0;
}
