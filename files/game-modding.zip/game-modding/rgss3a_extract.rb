# RGSSAD v3 (RPG Maker VX Ace) extractor.
# usage: ruby rgss3a_extract.rb <archive> [out_dir] [filter]
require 'fileutils'

src = ARGV[0] or abort "need archive"
dst = ARGV[1] || 'extracted'
filter = ARGV[2]

bin = File.binread(src)
abort "not RGSSAD v3" unless bin[0, 8] == "RGSSAD\0\x03".b

seed = bin[8, 4].unpack1('V')
key = (seed * 9 + 3) & 0xFFFFFFFF
pos = 12

advance = ->(k) { (k * 7 + 3) & 0xFFFFFFFF }

decrypt_data = lambda do |bytes, fkey|
  out = String.new(capacity: bytes.bytesize)
  k = fkey
  i = 0
  while i < bytes.bytesize
    take = [4, bytes.bytesize - i].min
    take.times do |j|
      out << ((bytes.getbyte(i + j) ^ ((k >> (j * 8)) & 0xFF)) & 0xFF).chr
    end
    k = advance.call(k)
    i += take
  end
  out
end

count = 0
extracted = 0
while pos < bin.bytesize
  offset = bin[pos, 4].unpack1('V') ^ key; pos += 4
  break if offset == 0
  size     = bin[pos, 4].unpack1('V') ^ key; pos += 4
  fkey     = bin[pos, 4].unpack1('V') ^ key; pos += 4
  name_len = bin[pos, 4].unpack1('V') ^ key; pos += 4
  name_bytes = bin[pos, name_len].bytes; pos += name_len
  key_bytes = [key].pack('V').bytes
  name = name_bytes.each_with_index.map { |b, i| (b ^ key_bytes[i % 4]).chr }.join
  count += 1

  if filter && !name.include?(filter)
    next
  end

  data = decrypt_data.call(bin[offset, size], fkey)
  out_path = File.join(dst, name.gsub('\\', '/'))
  FileUtils.mkdir_p(File.dirname(out_path))
  File.binwrite(out_path, data)
  extracted += 1
  puts "  -> #{name} (#{size} bytes)"
end

puts "scanned #{count}, extracted #{extracted}"
