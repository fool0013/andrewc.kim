# RGSSAD v1 (RPG Maker XP) extractor , corrected.
# Key model:
#   - Outer key starts at 0xDEADCAFE.
#   - Each header field (name_len, each name byte, size) advances the outer key
#     after consumption.
#   - The data section uses a SCRATCH copy of the outer key. XOR uses the
#     scratch key as a 4-byte little-endian window; scratch advances once
#     per dword consumed. Outer key is NOT touched during data.

src = ARGV[0]
dst = ARGV[1] || 'extracted'
filter = ARGV[2]

require 'fileutils'
data = File.binread(src)
raise "not RGSSAD" unless data[0, 7] == "RGSSAD\0"
puts "version: #{data[7].ord}"

pos = 8
key = 0xDEADCAFE
ADV = ->(k) { (k * 7 + 3) & 0xFFFFFFFF }

read_u32_xor = lambda {
  v = data[pos, 4].unpack1('V'); pos += 4
  out = v ^ key
  key = ADV.call(key)
  out
}

read_name = lambda { |n|
  buf = data[pos, n].bytes; pos += n
  out = String.new(capacity: n)
  buf.each do |b|
    out << ((b ^ (key & 0xFF)) & 0xFF).chr
    key = ADV.call(key)
  end
  out
}

read_data = lambda { |n|
  out = String.new(capacity: n)
  scratch = key   # snapshot , outer key not advanced by data XOR
  i = 0
  while i < n
    take = [4, n - i].min
    chunk = data[pos + i, take].bytes
    take.times { |j| out << ((chunk[j] ^ ((scratch >> (j * 8)) & 0xFF)) & 0xFF).chr }
    scratch = ADV.call(scratch)
    i += take
  end
  pos += n
  out
}

entries = 0
extracted_count = 0
while pos < data.bytesize
  name_len = read_u32_xor.call
  if name_len < 1 || name_len > 1024
    puts "stop: bad name_len=#{name_len} at pos #{pos}"
    break
  end
  name = read_name.call(name_len)
  size = read_u32_xor.call
  if size < 0 || size > 200_000_000
    puts "stop: bad size=#{size} for #{name.inspect}"
    break
  end
  contents = read_data.call(size)
  entries += 1

  unless filter && !name.include?(filter)
    out_path = File.join(dst, name.gsub('\\', '/'))
    FileUtils.mkdir_p(File.dirname(out_path))
    File.binwrite(out_path, contents)
    extracted_count += 1
  end
end

puts "scanned #{entries}, extracted #{extracted_count} (filter=#{filter.inspect})"
