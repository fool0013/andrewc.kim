import argparse
import bisect
import os
import time

from beatmap import MANIA, STANDARD, parse
from keys import Columns, Hands, binding_scan_code, character_scan_code, kill_switch_pressed
from osu_memory import AUTOPLAY, KEY_MODS, MIRROR, PLAYING, RANDOM, Osu, read_config
from winprocess import GameProcess, find_pids

SEEK_THRESHOLD_MS = 100

DEFAULT_MANIA_LAYOUTS = {
    1: " ",
    2: "fj",
    3: "f j",
    4: "dfjk",
    5: "df jk",
    6: "sdfjkl",
    7: "sdf jkl",
    8: "asdfjkl;",
    9: "asdf jkl;",
    10: "asdfvnjkl;",
}

def attach():
    print("waiting for osu! stable")
    while not kill_switch_pressed():
        for pid in find_pids("osu!.exe"):
            process = GameProcess(pid)
            if process.is_32_bit(): return process
            process.close()
        time.sleep(1)
    raise SystemExit("stopped")

def locate(process):
    print("scanning memory")
    warned = False
    while True:
        try:
            return Osu(process)
        except LookupError as error:
            if kill_switch_pressed() or not process.alive(): raise SystemExit(f"gave up: {error}")
            if not warned:
                print(f"{error}, retrying while osu! finishes loading")
                warned = True
            time.sleep(2)

def stop_reason():
    if kill_switch_pressed(): return "stopped"
    return None

def build_presser(beatmap, game_mode, mods, osu_codes, mania_codes, tap_ms):
    if mods & AUTOPLAY: raise ValueError("autoplay is on")
    if beatmap.mode == MANIA:
        if mods & RANDOM: raise ValueError("random mod shuffles columns")
        if mods & KEY_MODS: raise ValueError("key count mods aren't supported")
        if beatmap.key_count not in mania_codes: raise ValueError(f"no key layout for {beatmap.key_count}k")
        codes = list(mania_codes[beatmap.key_count])
        if mods & MIRROR: codes.reverse()
        return Columns(codes, tap_ms)
    if game_mode != STANDARD: raise ValueError("converted maps aren't supported")
    return Hands(osu_codes, tap_ms)

def play(osu, objects, presser, offset):
    starts = [hit.time for hit in objects]
    previous = osu.audio_time() + offset
    index = bisect.bisect_left(starts, previous)
    while osu.status() == PLAYING:
        reason = stop_reason()
        if reason: return reason
        now = osu.audio_time() + offset
        if now < previous - SEEK_THRESHOLD_MS:
            presser.release_all()
            index = bisect.bisect_left(starts, now)
        previous = now
        presser.update(now)
        while index < len(objects) and objects[index].time <= now:
            presser.hit(objects[index])
            index += 1
    return None

def wait_until_not_playing(osu):
    while osu.status() == PLAYING and not stop_reason():
        time.sleep(0.05)

def run(osu, songs_dir, osu_codes, mania_codes, args):
    while True:
        reason = stop_reason()
        if reason: return reason
        if osu.status() != PLAYING:
            time.sleep(0.05)
            continue
        if osu.watching_replay():
            wait_until_not_playing(osu)
            continue

        path = osu.beatmap_path(songs_dir)
        try:
            beatmap = parse(path)
            presser = build_presser(beatmap, osu.game_mode(), osu.mods(), osu_codes, mania_codes, args.tap_ms)
        except (OSError, ValueError, IndexError) as error:
            print(f"skipping map: {error}")
            wait_until_not_playing(osu)
            continue

        mode_name = f"{beatmap.key_count}k mania" if beatmap.mode == MANIA else "standard"
        print(f"playing {os.path.basename(path)} ({mode_name}, {len(beatmap.objects)} objects)")
        try:
            reason = play(osu, beatmap.objects, presser, args.offset)
        finally:
            presser.release_all()
        if reason: return reason

def main():
    parser = argparse.ArgumentParser(description="key bot for osu! stable (standard relax and mania)")
    parser.add_argument("--offset", type=int, default=0, help="press this many ms early (negative for late)")
    parser.add_argument("--tap-ms", type=int, default=30, help="how long a tap holds the key")
    parser.add_argument("--mania-keys", nargs="+", default=[], metavar="LAYOUT", help='mania layouts, one per key count, e.g. "dfjk" "sdf jkl"')
    args = parser.parse_args()

    layouts = dict(DEFAULT_MANIA_LAYOUTS)
    for layout in args.mania_keys:
        layouts[len(layout)] = layout.lower()
    mania_codes = {count: [character_scan_code(character) for character in layout] for count, layout in layouts.items()}

    process = attach()
    osu = locate(process)
    osu_dir = os.path.dirname(process.exe_path())
    config = read_config(osu_dir)
    songs_dir = os.path.join(osu_dir, config.get("BeatmapDirectory", "Songs"))
    osu_codes = [binding_scan_code(config.get("keyOsuLeft", "Z")), binding_scan_code(config.get("keyOsuRight", "X"))]

    print("ready, start a map (end key quits)")
    print(run(osu, songs_dir, osu_codes, mania_codes, args))

if __name__ == "__main__":
    main()
