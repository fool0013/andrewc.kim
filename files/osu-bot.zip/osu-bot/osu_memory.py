import os

PLAYING = 2

AUTOPLAY = 1 << 11
RANDOM = 1 << 21
MIRROR = 1 << 30
KEY_MODS = sum(1 << bit for bit in (15, 16, 17, 18, 19, 24, 25, 26, 27, 28))

PATTERNS = {
    "base": "F8 01 74 04 83 65",
    "play_time": "5E 5F 5D C3 A1 ?? ?? ?? ?? 89 ?? 04",
    "status": "48 83 F8 04 73 1E",
    "login": "B8 0B 00 00 8B 35",
    "replay": "55 8B EC 80 3D ?? ?? ?? ?? 00 75 26 80 3D",
    "mods": "C8 FF ?? ?? ?? ?? ?? 81 0D ?? ?? ?? ?? ?? 08 00 00",
}

class Osu:
    def __init__(self, process):
        found = process.scan(PATTERNS)
        missing = sorted(set(PATTERNS) - set(found))
        if missing: raise LookupError("signatures not found: " + ", ".join(missing))

        self.process = process
        self.beatmap_slot = process.uint32(found["base"] - 0xC)
        self.mode_slot = process.uint32(found["base"] - 0x33)
        self.mods_address = process.uint32(found["mods"] + 0x9)
        self.time_address = process.uint32(found["play_time"] + 0x5)
        self.status_address = process.uint32(found["status"] - 0x4)
        self.login_address = process.uint32(found["login"] - 0xB)
        self.replay_address = process.uint32(found["replay"] + 0x46)

    def audio_time(self):
        return self.process.int32(self.time_address)

    def status(self):
        return self.process.int32(self.status_address)

    def login_status(self):
        return self.process.int32(self.login_address)

    def game_mode(self):
        return self.process.int32(self.mode_slot)

    def mods(self):
        return self.process.int32(self.mods_address)

    def watching_replay(self):
        return self.process.byte(self.replay_address) == 1

    def beatmap_path(self, songs_dir):
        beatmap = self.process.uint32(self.beatmap_slot)
        folder = self.process.string(self.process.uint32(beatmap + 0x78))
        filename = self.process.string(self.process.uint32(beatmap + 0x90))
        return os.path.join(songs_dir, folder, filename)

def read_config(osu_dir):
    path = os.path.join(osu_dir, f"osu!.{os.environ.get('USERNAME', '')}.cfg")
    config = {}
    if not os.path.exists(path): return config
    with open(path, encoding="utf-8-sig", errors="replace") as file:
        for line in file:
            key, separator, value = line.partition("=")
            if separator: config[key.strip()] = value.strip()
    return config
