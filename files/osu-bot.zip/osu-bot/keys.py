import ctypes
import re
from ctypes import wintypes

user32 = ctypes.WinDLL("user32", use_last_error=True)

INPUT_KEYBOARD = 1
KEY_UP = 0x2
USE_SCAN_CODE = 0x8
VK_END = 0x23

class KeyboardInput(ctypes.Structure):
    _fields_ = [
        ("virtual_key", wintypes.WORD),
        ("scan_code", wintypes.WORD),
        ("flags", wintypes.DWORD),
        ("time", wintypes.DWORD),
        ("extra", ctypes.c_size_t),
    ]

class MouseInput(ctypes.Structure):
    _fields_ = [
        ("dx", wintypes.LONG),
        ("dy", wintypes.LONG),
        ("data", wintypes.DWORD),
        ("flags", wintypes.DWORD),
        ("time", wintypes.DWORD),
        ("extra", ctypes.c_size_t),
    ]

class InputUnion(ctypes.Union):
    _fields_ = [("keyboard", KeyboardInput), ("mouse", MouseInput)]

class Input(ctypes.Structure):
    _fields_ = [("type", wintypes.DWORD), ("event", InputUnion)]

user32.SendInput.argtypes = [wintypes.UINT, ctypes.POINTER(Input), ctypes.c_int]
user32.SendInput.restype = wintypes.UINT
user32.MapVirtualKeyW.argtypes = [wintypes.UINT, wintypes.UINT]
user32.MapVirtualKeyW.restype = wintypes.UINT
user32.VkKeyScanW.argtypes = [wintypes.WCHAR]
user32.VkKeyScanW.restype = ctypes.c_short
user32.GetAsyncKeyState.argtypes = [ctypes.c_int]
user32.GetAsyncKeyState.restype = ctypes.c_short

def binding_scan_code(binding):
    match = re.fullmatch(r"([A-Za-z])|D([0-9])", binding)
    if not match: raise ValueError(f"unsupported osu! key binding {binding!r}, bind keys to letters or digits")
    return character_scan_code((match.group(1) or match.group(2)).lower())

def character_scan_code(character):
    result = user32.VkKeyScanW(character)
    if result == -1 or result >> 8: raise ValueError(f"{character!r} isn't a single unshifted key on this keyboard layout")
    return user32.MapVirtualKeyW(result & 0xFF, 0)

def send_key(code, up):
    event = Input(type=INPUT_KEYBOARD)
    event.event.keyboard = KeyboardInput(scan_code=code, flags=USE_SCAN_CODE | (KEY_UP if up else 0))
    if user32.SendInput(1, ctypes.byref(event), ctypes.sizeof(Input)) != 1: raise OSError(f"SendInput failed (error {ctypes.get_last_error()})")

def kill_switch_pressed():
    return (user32.GetAsyncKeyState(VK_END) & 0x8000) != 0

class KeyPresser:
    def __init__(self, codes, tap_ms):
        self.codes = codes
        self.tap_ms = tap_ms
        self.release_at = [None] * len(codes)

    def press(self, index, hit):
        if self.release_at[index] is not None: send_key(self.codes[index], up=True)
        send_key(self.codes[index], up=False)
        self.release_at[index] = max(hit.end_time, hit.time + self.tap_ms)

    def update(self, now):
        for index, release_time in enumerate(self.release_at):
            if release_time is not None and now >= release_time:
                send_key(self.codes[index], up=True)
                self.release_at[index] = None

    def release_all(self):
        for index, release_time in enumerate(self.release_at):
            if release_time is not None:
                send_key(self.codes[index], up=True)
                self.release_at[index] = None

class Hands(KeyPresser):
    def __init__(self, codes, tap_ms):
        super().__init__(codes, tap_ms)
        self.turn = 0

    def hit(self, hit):
        preferred = [self.turn, 1 - self.turn]
        free = [index for index in preferred if self.release_at[index] is None]
        index = free[0] if free else preferred[0]
        self.press(index, hit)
        self.turn = 1 - index

class Columns(KeyPresser):
    def hit(self, hit):
        self.press(hit.column, hit)
