from collections import namedtuple

STANDARD = 0
MANIA = 3
SLIDER = 2
SPINNER = 8
HOLD = 128

HitObject = namedtuple("HitObject", "time end_time column")
TimingPoint = namedtuple("TimingPoint", "time beat_length uninherited")
Beatmap = namedtuple("Beatmap", "mode key_count objects")

def read_sections(path):
    sections = {}
    current = None
    with open(path, encoding="utf-8-sig", errors="replace") as file:
        for raw_line in file:
            line = raw_line.strip()
            if not line or line.startswith("//"): continue
            if line.startswith("[") and line.endswith("]"):
                current = sections.setdefault(line[1:-1], [])
            elif current is not None:
                current.append(line)
    return sections

def read_pairs(lines):
    pairs = {}
    for line in lines:
        key, _, value = line.partition(":")
        pairs[key.strip()] = value.strip()
    return pairs

def read_timing_points(lines):
    points = []
    for line in lines:
        fields = line.split(",")
        beat_length = float(fields[1])
        uninherited = fields[6] == "1" if len(fields) > 6 else beat_length > 0
        points.append(TimingPoint(float(fields[0]), beat_length, uninherited))
    points.sort(key=lambda point: (point.time, not point.uninherited))
    return points

def slider_velocity(point):
    if point.beat_length >= 0: return 1.0
    return min(max(-100 / point.beat_length, 0.1), 10.0)

def parse_standard_objects(lines, points, slider_multiplier):
    beat_lengths = [point.beat_length for point in points if point.uninherited]
    if not beat_lengths: raise ValueError("map has no uninherited timing points")

    beat_length = beat_lengths[0]
    velocity = 1.0
    next_point = 0
    objects = []
    for line in lines:
        fields = line.split(",")
        time = int(float(fields[2]))
        kind = int(fields[3])

        while next_point < len(points) and points[next_point].time <= time:
            point = points[next_point]
            if point.uninherited:
                beat_length = point.beat_length
                velocity = 1.0
            else:
                velocity = slider_velocity(point)
            next_point += 1

        if kind & SLIDER:
            slides = int(fields[6])
            length = float(fields[7])
            duration = slides * length / (slider_multiplier * 100 * velocity) * beat_length
            objects.append(HitObject(time, time + round(duration), 0))
        elif kind & SPINNER:
            objects.append(HitObject(time, int(float(fields[5])), 0))
        else:
            objects.append(HitObject(time, time, 0))
    return objects

def parse_mania_objects(lines, key_count):
    objects = []
    for line in lines:
        fields = line.split(",")
        time = int(float(fields[2]))
        column = min(int(float(fields[0]) * key_count / 512), key_count - 1)
        end_time = int(float(fields[5].split(":")[0])) if int(fields[3]) & HOLD else time
        objects.append(HitObject(time, max(end_time, time), column))
    objects.sort(key=lambda hit: hit.time)
    return objects

def parse(path):
    sections = read_sections(path)
    mode = int(read_pairs(sections.get("General", [])).get("Mode", "0"))
    difficulty = read_pairs(sections.get("Difficulty", []))
    lines = sections.get("HitObjects", [])

    if mode == MANIA:
        key_count = round(float(difficulty.get("CircleSize", "4")))
        return Beatmap(mode, key_count, parse_mania_objects(lines, key_count))

    if mode == STANDARD:
        slider_multiplier = float(difficulty.get("SliderMultiplier", "1.4"))
        points = read_timing_points(sections.get("TimingPoints", []))
        return Beatmap(mode, 0, parse_standard_objects(lines, points, slider_multiplier))

    raise ValueError("only osu!standard and mania maps are supported")
