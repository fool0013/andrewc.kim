import ctypes
import re
from ctypes import wintypes

kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)

PROCESS_ACCESS = 0x0010 | 0x0400
SNAPSHOT_PROCESSES = 0x2
STILL_ACTIVE = 259
MEM_COMMIT = 0x1000
SCANNABLE_PAGES = 0x04 | 0x40
ADDRESS_LIMIT = 0x100000000

class ProcessEntry(ctypes.Structure):
    _fields_ = [
        ("size", wintypes.DWORD),
        ("usage", wintypes.DWORD),
        ("pid", wintypes.DWORD),
        ("heap_id", ctypes.c_size_t),
        ("module_id", wintypes.DWORD),
        ("threads", wintypes.DWORD),
        ("parent_pid", wintypes.DWORD),
        ("priority", ctypes.c_long),
        ("flags", wintypes.DWORD),
        ("exe_name", ctypes.c_wchar * 260),
    ]

class MemoryRegion(ctypes.Structure):
    _fields_ = [
        ("base", ctypes.c_uint64),
        ("allocation_base", ctypes.c_uint64),
        ("allocation_protect", wintypes.DWORD),
        ("partition", wintypes.WORD),
        ("size", ctypes.c_size_t),
        ("state", wintypes.DWORD),
        ("protect", wintypes.DWORD),
        ("type", wintypes.DWORD),
    ]

def bind(name, restype, *argtypes):
    function = getattr(kernel32, name)
    function.restype = restype
    function.argtypes = argtypes
    return function

open_process = bind("OpenProcess", wintypes.HANDLE, wintypes.DWORD, wintypes.BOOL, wintypes.DWORD)
close_handle = bind("CloseHandle", wintypes.BOOL, wintypes.HANDLE)
read_memory = bind("ReadProcessMemory", wintypes.BOOL, wintypes.HANDLE, ctypes.c_void_p, ctypes.c_void_p, ctypes.c_size_t, ctypes.POINTER(ctypes.c_size_t))
virtual_query = bind("VirtualQueryEx", ctypes.c_size_t, wintypes.HANDLE, ctypes.c_void_p, ctypes.POINTER(MemoryRegion), ctypes.c_size_t)
create_snapshot = bind("CreateToolhelp32Snapshot", wintypes.HANDLE, wintypes.DWORD, wintypes.DWORD)
first_process = bind("Process32FirstW", wintypes.BOOL, wintypes.HANDLE, ctypes.POINTER(ProcessEntry))
next_process = bind("Process32NextW", wintypes.BOOL, wintypes.HANDLE, ctypes.POINTER(ProcessEntry))
exit_code = bind("GetExitCodeProcess", wintypes.BOOL, wintypes.HANDLE, ctypes.POINTER(wintypes.DWORD))
is_wow64 = bind("IsWow64Process", wintypes.BOOL, wintypes.HANDLE, ctypes.POINTER(wintypes.BOOL))
image_name = bind("QueryFullProcessImageNameW", wintypes.BOOL, wintypes.HANDLE, wintypes.DWORD, wintypes.LPWSTR, ctypes.POINTER(wintypes.DWORD))

def find_pids(exe_name):
    snapshot = create_snapshot(SNAPSHOT_PROCESSES, 0)
    entry = ProcessEntry()
    entry.size = ctypes.sizeof(ProcessEntry)

    pids = []
    found = first_process(snapshot, ctypes.byref(entry))
    while found:
        if entry.exe_name.lower() == exe_name.lower(): pids.append(entry.pid)
        found = next_process(snapshot, ctypes.byref(entry))

    close_handle(snapshot)
    return pids

def compile_pattern(text):
    pieces = [b"." if token == "??" else re.escape(bytes([int(token, 16)])) for token in text.split()]
    return re.compile(b"".join(pieces), re.DOTALL)

class GameProcess:
    def __init__(self, pid):
        self.pid = pid
        self.handle = open_process(PROCESS_ACCESS, False, pid)
        if not self.handle: raise OSError(f"could not open process {pid} (error {ctypes.get_last_error()})")

    def close(self):
        close_handle(self.handle)

    def is_32_bit(self):
        flag = wintypes.BOOL()
        is_wow64(self.handle, ctypes.byref(flag))
        return bool(flag.value)

    def alive(self):
        code = wintypes.DWORD()
        exit_code(self.handle, ctypes.byref(code))
        return code.value == STILL_ACTIVE

    def exe_path(self):
        size = wintypes.DWORD(1024)
        buffer = ctypes.create_unicode_buffer(size.value)
        image_name(self.handle, 0, buffer, ctypes.byref(size))
        return buffer.value

    def read(self, address, size):
        buffer = ctypes.create_string_buffer(size)
        if not read_memory(self.handle, address, buffer, size, None): raise MemoryError(f"read failed at {address:#x}")
        return buffer.raw

    def int32(self, address):
        value = ctypes.c_int32()
        if not read_memory(self.handle, address, ctypes.byref(value), 4, None): raise MemoryError(f"read failed at {address:#x}")
        return value.value

    def uint32(self, address):
        return self.int32(address) & 0xFFFFFFFF

    def byte(self, address):
        return self.read(address, 1)[0]

    def string(self, address):
        if address == 0: return ""
        length = self.int32(address + 4)
        if not 0 <= length <= 4096: raise MemoryError(f"implausible string length {length} at {address:#x}")
        return self.read(address + 8, length * 2).decode("utf-16-le")

    def regions(self):
        region = MemoryRegion()
        address = 0
        while address < ADDRESS_LIMIT and virtual_query(self.handle, address, ctypes.byref(region), ctypes.sizeof(region)):
            yield region.base, region.size, region.state, region.protect
            address = region.base + region.size

    def scan(self, patterns):
        compiled = {name: compile_pattern(text) for name, text in patterns.items()}
        found = {}
        for base, size, state, protect in self.regions():
            if state != MEM_COMMIT or not protect & SCANNABLE_PAGES: continue
            try:
                data = self.read(base, size)
            except MemoryError:
                continue
            for name, pattern in compiled.items():
                if name in found: continue
                match = pattern.search(data)
                if match: found[name] = base + match.start()
            if len(found) == len(compiled): break
        return found
