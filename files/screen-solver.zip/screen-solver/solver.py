import mss
import mss.tools
import easyocr
from google import genai
import keyboard
import tkinter as tk
import ctypes
import difflib
import warnings
import os
import time

warnings.filterwarnings("ignore", category=UserWarning)

client = genai.Client(api_key=os.environ["GEMINI_API_KEY"])
flash_model = "gemini-2.5-flash"
pro_model = "gemini-2.5-pro"

reader = easyocr.Reader(["en"])
context = ""

def mouse_pos():
    class Point(ctypes.Structure):
        _fields_ = [("x", ctypes.c_long), ("y", ctypes.c_long)]
    point = Point()
    ctypes.windll.user32.GetCursorPos(ctypes.byref(point))
    return point.x, point.y

def save_context():
    global context
    mouse_x, mouse_y = mouse_pos()

    with mss.mss() as sct:
        monitor = sct.monitors[1]
        for m in sct.monitors[1:]:
            if (m["left"] <= mouse_x < m["left"] + m["width"] and
                    m["top"] <= mouse_y < m["top"] + m["height"]):
                monitor = m
                break

        shot = sct.grab(monitor)
        mss.tools.to_png(shot.rgb, shot.size, output="temp_context.png")

    words = reader.readtext("temp_context.png", detail=0)
    text = " ".join(words)

    if len(text.strip()) > 10:
        context += text + "\n\n"
        print(f"saved {len(text)} chars of context")
    else:
        print("not enough text to save")

def solve(use_pro=False):
    global context
    mouse_x, mouse_y = mouse_pos()

    monitor = None
    with mss.mss() as sct:
        monitor = sct.monitors[1]
        for m in sct.monitors[1:]:
            if (m["left"] <= mouse_x < m["left"] + m["width"] and
                    m["top"] <= mouse_y < m["top"] + m["height"]):
                monitor = m
                break

        shot = sct.grab(monitor)
        mss.tools.to_png(shot.rgb, shot.size, output="temp_cap.png")

    boxes = reader.readtext("temp_cap.png")
    texts = [box[1] for box in boxes]
    screen_text = " ".join(texts)

    if len(screen_text.strip()) < 5:
        print("not enough text on screen")
        return

    question = f"Background Information:\n{context}\n\nQuestion and Choices:\n{screen_text}"
    prompt = f"You are an expert test solver. Respond ONLY with the EXACT TEXT of the correct answer choice as it appears in the image. No letters, no intro.\n\n{question}"

    for attempt in range(3):
        try:
            model = pro_model if use_pro else flash_model
            response = client.models.generate_content(model=model, contents=prompt)

            reply = response.text.strip()
            answer = reply.lower()
            print(f"gemini: {reply}")

            best_box = None
            best_score = 0.0

            for box in boxes:
                box_text = box[1].lower().strip()
                score = difflib.SequenceMatcher(None, answer, box_text).ratio()
                if (box_text in answer or answer in box_text) and len(box_text) > 3:
                    score += 0.5

                if score > best_score:
                    best_score = score
                    best_box = box

            if best_box and best_score > 0.4:
                print(f"match: {best_box[1]} ({best_score:.2f})")
                corners = best_box[0]
                dot_x = int(corners[1][0]) + monitor["left"] + 15
                dot_y = int((corners[1][1] + corners[2][1]) / 2) + monitor["top"]
                show_dot(dot_x, dot_y)
                break
            else:
                print("no match on screen")
                break

        except Exception as e:
            print(f"error: {e}, retrying")
            time.sleep(1)
            if attempt == 2:
                print("gave up after 3 tries")

    context = ""

def show_dot(x, y):
    root = tk.Tk()
    root.overrideredirect(True)
    root.attributes("-topmost", True, "-transparentcolor", "white")
    root.config(bg="white")

    size = 10
    left = x
    top = y - (size // 2)

    root.geometry(f"{size}x{size}+{int(left)}+{int(top)}")

    canvas = tk.Canvas(root, bg="white", highlightthickness=0)
    canvas.pack(fill="both", expand=True)
    canvas.create_oval(0, 0, size, size, fill="black", outline="black")

    root.after(4000, root.destroy)
    root.mainloop()

def stop():
    os._exit(0)

print("ready. ctrl+shift+1 flash, ctrl+shift+2 pro, ctrl+shift+x save context, ctrl+shift+q quit")
keyboard.add_hotkey("ctrl+shift+x", save_context)
keyboard.add_hotkey("ctrl+shift+1", lambda: solve(use_pro=False))
keyboard.add_hotkey("ctrl+shift+2", lambda: solve(use_pro=True))
keyboard.add_hotkey("ctrl+shift+q", stop)

keyboard.wait()
