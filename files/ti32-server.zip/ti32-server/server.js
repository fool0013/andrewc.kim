import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import OpenAI from 'openai';

const app = express();
app.use(cors());

const client = new OpenAI({ apiKey: process.env.TI32_OPENAI_KEY });
const PORT = process.env.PORT || 8000;
const MODEL = process.env.MODEL || 'gpt-4.1-mini';
const SYSTEM_PROMPT = 'You are a concise advanced math, calculus, language arts, and computer science assistant. Show steps clearly but keep answers short enough to fit on a TI-84-sized screen.';

app.get('/gpt/ask', async (req, res) => {
  const question = (req.query.question || '').toString().trim();
  if (!question) return res.status(400).type('text/plain').send('no question');

  try {
    const completion = await client.chat.completions.create({
      model: MODEL,
      messages: [
        { role: 'system', content: SYSTEM_PROMPT },
        { role: 'user', content: question },
      ],
      max_tokens: 400,
    });
    const reply = completion.choices[0]?.message?.content?.trim() || 'no response';
    console.log(`q: ${question}\na: ${reply}`);
    res.type('text/plain').send(reply);
  } catch (err) {
    console.error(err);
    res.status(500).type('text/plain').send('error talking to gpt');
  }
});

app.listen(PORT, () => console.log(`listening on ${PORT}`));
