import sys, os, glob, shutil, subprocess, time
BK = os.path.join(os.path.dirname(os.path.abspath(__file__)), "backup")
DB = os.path.join(os.environ["LOCALAPPDATA"], "LGHUB", "settings.db")
snaps = sorted({os.path.basename(p).split('.')[-2] for p in glob.glob(os.path.join(BK,"settings.db.*.bak"))})
if len(sys.argv) < 2:
    print("backups available:"); [print("  ",s) for s in snaps]
    print("\nrestore with:  python restore.py <stamp>"); sys.exit()
st = sys.argv[1]
src = os.path.join(BK, f"settings.db.{st}.bak")
if not os.path.exists(src): sys.exit("no backup with stamp "+st)
print("stopping g hub...")
for n in ("lghub","lghub_system_tray","lghub_agent"):
    subprocess.run(["taskkill","/F","/IM",n+".exe"],capture_output=True)
time.sleep(2)
for suf in ("-wal","-shm"):
    if os.path.exists(DB+suf): os.remove(DB+suf)
shutil.copy2(src, DB)
for suf in ("-wal","-shm"):
    b = os.path.join(BK, f"settings.db{suf}.{st}.bak")
    if os.path.exists(b): shutil.copy2(b, DB+suf)
print("restored", src)
subprocess.Popen([r"C:\Program Files\LGHUB\lghub.exe"])
print("g hub restarting -- old preset is back")
