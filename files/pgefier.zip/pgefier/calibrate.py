import sys, os, json, shutil, subprocess, argparse
import numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import dsp, apply_pge

HERE = os.path.dirname(os.path.abspath(__file__))
TGT  = json.load(open(os.path.join(HERE,"pge_target.json")))
FFMPEG = os.environ.get("FFMPEG") or shutil.which("ffmpeg") or "ffmpeg"
MIC = "Microphone (mic)"
TALK, PAUSE, TYPE = 45, 5, 20
FIT = [b for b in sorted(TGT,key=int) if 100 <= int(b) <= 6300]

def rec(path, secs):
    subprocess.run([FFMPEG,"-nostdin","-v","error","-y","-f","dshow","-i",f"audio={MIC}",
                    "-t",str(secs),"-c:a","pcm_s16le","-ar","48000",path], check=True)

ap = argparse.ArgumentParser()
ap.add_argument("--write", action="store_true")
ap.add_argument("--keep", action="store_true", help="skip recording, reuse last take")
a = ap.parse_args()

raw = os.path.join(HERE,"calib_raw.wav")

if not a.keep:
    print("\n  Bypassing processing so we measure the bare mic...")
    apply_pge.push(apply_pge.FLAT, "pge match")
    total = TALK+PAUSE+TYPE
    print(f"""
  {total}s take, sit where you normally sit:
    0-{TALK}s        TALK normally. game voice, not radio voice. keep going, don't trail off.
    {TALK}-{TALK+PAUSE}s       say nothing, hands off the keyboard.
    {TALK+PAUSE}-{total}s      say nothing, TYPE like you do in game.
""")
    input("  press enter to start ")
    print("  recording... TALK NOW")
    rec(raw, total)
    print("  done")

sr, M, S = dsp.load(raw)
nt, np_, ny = int(TALK*sr), int((TALK+PAUSE)*sr), int((TALK+PAUSE+TYPE)*sr)
Mt, St = M[:nt], S[:nt]
Mk     = M[np_:ny]
if len(Mk) < sr: sys.exit("recording too short -- rerun without --keep")

cur, spl, nact = dsp.voice_curve(Mt, St, sr, TGT)
if nact < 50: sys.exit("barely any speech found -- rerun and keep talking")
kb = dsp.levels(Mk)

fc  = np.array([float(k) for k in FIT])
des = np.array([TGT[k]-cur[k] for k in FIT])
w   = np.ones_like(fc)
w[(fc>=100)&(fc<200)]   = 1.5
w[(fc>=200)&(fc<=4000)] = 2.0
w[fc>=5000]             = 0.5
bands, got = dsp.fit(des, fc, w)

print("\n  band      raw you   pge     want    eq gives   left")
for i,k in enumerate(FIT):
    print(f"  {k:>6}Hz  {cur[k]:7.2f} {TGT[k]:7.2f} {des[i]:+7.2f}  {got[i]:+8.2f}  {des[i]-got[i]:+6.2f}")
e0 = float(np.sqrt(np.average(des**2,weights=w)))
e1 = float(np.sqrt(np.average((des-got)**2,weights=w)))
print(f"\n  spectrum error: {e0:.2f} dB -> {e1:.2f} dB")

sp_lo, kb_hi = np.percentile(spl,5), np.percentile(kb,95)
gap = sp_lo - kb_hi
print(f"\n  quiet speech (p5) {sp_lo:6.1f} dBFS")
print(f"  keyboard   (p95)  {kb_hi:6.1f} dBFS   peak {kb.max():.1f}")
print(f"  separation        {gap:+6.1f} dB")
if gap >= 6:
    gate = int(round(kb_hi + gap*0.4)); note="clean separation"
elif gap > 0:
    gate = int(round(kb_hi + 1)); note="tight -- may clip the start of quiet words"
else:
    gate = int(round(sp_lo - 2)); note="NO separation: keyboard is as loud as your quiet speech"
gate = max(-80, min(-24, gate))
print(f"  -> gate threshold {gate} dBFS  ({note})")

sd = float(spl.std())
ratio = int(max(3, min(8, round(sd/2.7))))
thr   = int(max(-30, min(-5, round(np.median(spl) - 2))))
print(f"  your raw speech sd {sd:.2f} dB -> ratio {ratio}:1 @ {thr} dB  (pge sits at 2.3-3.1)")
pk = 20*np.log10(max(abs(M[:nt]).max(),1e-12))
if pk > -1.0: print(f"  !! raw peak {pk:.1f} dBFS -- turn the mic knob DOWN, you're near clipping")
elif pk < -20: print(f"  !! raw peak {pk:.1f} dBFS -- turn the mic knob UP")

s = json.loads(json.dumps(apply_pge.PGE))
s["multiBandEq"] = {"enabled":True,"lowBandFilter":bands["low"],
                    "midBandFilter":bands["mid"],"highBandFilter":bands["high"]}
s["gatingCompressor"]["noiseGateThreshold"] = gate
s["gatingCompressor"]["compressorRatio"]    = ratio
s["gatingCompressor"]["compressorThreshold"] = thr

print("\n  fitted chain:")
for k in ("low","mid","high"):
    b=bands[k]; print(f"    eq {k:<5} {b['frequency']:>5} Hz  {b['gain']:+3d} dB  q {b['q']}")
print(f"    gate {gate} dBFS / -45 max   comp {ratio}:1 @ {thr}")

if a.write:
    json.dump(s, open(os.path.join(HERE,"fitted.json"),"w"), indent=1)
    apply_pge.push(s, "pge match")
    print("\n  live in every app profile. fitted.json has the values.")
    if gap <= 0:
        print("  NOTE: no gate setting separates your keyboard from your voice.")
        print("        move the mic off the desk (boom/arm), or further from the keyboard.")
else:
    print("\n  (add --write to push it live)")
