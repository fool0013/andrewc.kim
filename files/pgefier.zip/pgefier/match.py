import sys, json, os, wave, numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
TGT  = json.load(open(os.path.join(HERE, "pge_target.json")))
SHAKY = {"8000", "10000"}

def curve(path):
    w = wave.open(path, 'rb')
    sr, ch, sw = w.getframerate(), w.getnchannels(), w.getsampwidth()
    if sw != 2: sys.exit("need 16-bit wav")
    raw = np.frombuffer(w.readframes(w.getnframes()), dtype='<i2').astype(np.float64)/32768.
    x = raw.reshape(-1, ch)
    M = x.mean(axis=1)
    S = (x[:,0]-x[:,1])/2. if ch > 1 else np.zeros_like(M)
    N, hop = 2048, 512
    win = np.hanning(N); nf = 1 + (len(M)-N)//hop
    if nf < 50: sys.exit("recording too short, want >=30s")
    idx = np.arange(N)[None,:] + hop*np.arange(nf)[:,None]
    PM = np.abs(np.fft.rfft(M[idx]*win, axis=1))**2
    PS = np.abs(np.fft.rfft(S[idx]*win, axis=1))**2
    PV = np.maximum(PM-PS, 0.) if ch > 1 else PM
    f  = np.fft.rfftfreq(N, 1/sr)
    sb = (f>=300)&(f<3400)
    e  = 10*np.log10(np.maximum(PV[:,sb].sum(axis=1), 1e-20))
    act, bed = e >= np.percentile(e,75), e <= np.percentile(e,15)
    vs  = np.maximum(PV[act].mean(axis=0) - PV[bed].mean(axis=0), 1e-20)
    ref = 10*np.log10(vs[(f>=900)&(f<1100)].mean())
    lvl = 10*np.log10(np.maximum((M[idx]**2).mean(axis=1), 1e-20))
    return f, vs, ref, lvl, act, bed, sr

f, vs, ref, lvl, act, bed, sr = curve(sys.argv[1])
keys = sorted(TGT, key=int)
hi   = [int(k) for k in keys] + [12500]

print(f"\n{sys.argv[1]}  sr={sr}  speech frames={act.sum()}\n")
print("  band       you     pge    delta   move")
for i, k in enumerate(keys):
    lo, up = int(k), hi[i+1]
    m = (f>=lo)&(f<up)
    you = 10*np.log10(vs[m].mean()) - ref
    d   = TGT[k] - you
    flag = "  (unreliable)" if k in SHAKY else ""
    arrow = "" if abs(d) < 1.5 else ("boost %+.1f" % d if d > 0 else "cut %+.1f" % d)
    print(f"  {lo:>6}Hz {you:7.2f} {TGT[k]:7.2f} {d:+7.2f}   {arrow}{flag}")

ls = lvl[act]
print(f"\n  your speech level: mean {ls.mean():.1f} dBFS  sd {ls.std():.2f}  p5-p95 {np.percentile(ls,95)-np.percentile(ls,5):.1f} dB")
print(f"  pge  speech level:                        sd 2.3-3.1    p5-p95 7.9-10.6 dB")
print(f"  your floor: bed mean {lvl[bed].mean():.1f} dBFS, quietest frame {lvl.min():.1f} dBFS")
print(f"  pge  floor: bed mean -29 to -45,          quietest frame -45 to -72 dBFS")
print("\n  sd/spread bigger than pge's -> add compression. floor higher -> add gate.\n")
