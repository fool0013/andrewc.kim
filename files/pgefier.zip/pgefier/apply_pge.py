import sqlite3, json, shutil, sys, os, datetime

DB   = os.path.join(os.environ["LOCALAPPDATA"], "LGHUB", "settings.db")
BK   = os.path.join(os.path.dirname(os.path.abspath(__file__)), "backup")
SLOT = "mic_blue_voice_2_settings"
PRIMARY = "ad71f529-7ebf-4574-9241-4b59fe288514"

PGE = {
  "deEsser":   {"attack":3,"enabled":True,"frequency":6000,"maxAttenuation":-20,
                "release":150,"threshold":-18,"width":2},
  "dePopper":  {"attack":5,"enabled":True,"frequency":160,"maxAttenuation":-40,
                "release":120,"threshold":-18,"width":20},
  "gatingCompressor": {
                "compressorAttack":5,"compressorEnabled":True,"compressorPostGain":2,
                "compressorPreGain":2,"compressorRatio":4,"compressorRelease":100,
                "compressorThreshold":-14,
                "noiseGateAttack":5,"noiseGateEnabled":True,"noiseGateHoldTime":40,
                "noiseGateMaxAttenuation":-45,"noiseGateRelease":120,
                "noiseGateThreshold":-28},
  "hardLimiter": {"attack":2,"boost":-3,"enabled":True,"release":150},
  "highPassFilter": {"enabled":True,"frequency":80},
  "inputGain": 0.52,
  "multiBandEq": {"enabled":True,
                "lowBandFilter":  {"frequency":125, "gain":9,  "q":0.5},
                "midBandFilter":  {"frequency":1250,"gain":-2, "q":1},
                "highBandFilter": {"frequency":5000,"gain":-10,"q":1}},
  "noiseReduction": {"bias":5,"enabled":True,"maxAttenuation":-24,
                "release":250,"sensitivity":6},
}

def main():
    if not os.path.exists(DB): sys.exit("no settings.db at "+DB)
    ts = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
    os.makedirs(BK, exist_ok=True)
    for suf in ("", "-wal", "-shm"):
        if os.path.exists(DB+suf): shutil.copy2(DB+suf, os.path.join(BK, f"settings.db{suf}.{ts}.bak"))
    print(f"backed up settings.db(+wal/shm) -> {BK}  stamp {ts}")

    con = sqlite3.connect(DB)
    con.execute("PRAGMA wal_checkpoint(TRUNCATE)")
    row = con.execute("select _id, file from data order by _id desc limit 1").fetchone()
    rid, blob = row
    raw = blob.decode("utf-8") if isinstance(blob, bytes) else blob
    d = json.loads(raw)

    cards = d["cards"]["cards"]
    tgt = next((c for c in cards if c.get("id") == PRIMARY), None)
    if tgt is None: sys.exit("Primary card not found")
    if tgt.get("readOnly"): sys.exit("Primary is readOnly, refusing")

    old = tgt["blueVoice2Settings"]["settings"]
    with open(os.path.join(BK, f"primary-before.{ts}.json"), "w") as f:
        json.dump(old, f, indent=1)
    print(f"saved previous Primary settings -> primary-before.{ts}.json")

    tgt["blueVoice2Settings"]["settings"] = PGE
    tgt["name"] = "pge match"
    tgt["blueVoice2Settings"]["description"]["name"] = "pge match"

    moved = []
    for p in d["profiles"]["profiles"]:
        for a in p.get("assignments", []):
            if a.get("slotId") == SLOT and a.get("cardId") != PRIMARY:
                a["cardId"] = PRIMARY; moved.append(p.get("applicationId", "?")[:8])
    print(f"repointed {len(moved)} profile(s) to the pge preset: {moved}")

    out = json.dumps(d, indent=2, ensure_ascii=False).encode("utf-8")
    con.execute("update data set file=? where _id=?", (out, rid))
    con.commit()
    con.execute("PRAGMA wal_checkpoint(TRUNCATE)")
    con.close()
    print(f"wrote settings.db ({len(out)} bytes)")

if __name__ == "__main__":
    main()

import subprocess, time as _t

def stop_ghub():
    for n in ("lghub","lghub_system_tray","lghub_agent"):
        subprocess.run(["taskkill","/F","/IM",n+".exe"],capture_output=True)
    _t.sleep(2)

def start_ghub(wait=14):
    subprocess.Popen([r"C:\Program Files\LGHUB\lghub.exe"])
    _t.sleep(wait)

def push(settings, name):
    global PGE
    PGE = settings
    stop_ghub()
    main()
    start_ghub()

FLAT = {
  "deEsser":   {"attack":3,"enabled":False,"frequency":6000,"maxAttenuation":-20,
                "release":150,"threshold":-18,"width":2},
  "dePopper":  {"attack":5,"enabled":False,"frequency":160,"maxAttenuation":-40,
                "release":120,"threshold":-18,"width":20},
  "gatingCompressor": {
                "compressorAttack":5,"compressorEnabled":False,"compressorPostGain":1,
                "compressorPreGain":1,"compressorRatio":3,"compressorRelease":100,
                "compressorThreshold":-14,
                "noiseGateAttack":5,"noiseGateEnabled":False,"noiseGateHoldTime":40,
                "noiseGateMaxAttenuation":-20,"noiseGateRelease":120,
                "noiseGateThreshold":-80},
  "hardLimiter": {"attack":5,"boost":-3,"enabled":False,"release":150},
  "highPassFilter": {"enabled":False,"frequency":20},
  "inputGain": 0.52,
  "multiBandEq": {"enabled":False,
                "lowBandFilter":  {"frequency":125, "gain":0,"q":1},
                "midBandFilter":  {"frequency":1000,"gain":0,"q":1},
                "highBandFilter": {"frequency":5000,"gain":0,"q":1}},
  "noiseReduction": {"bias":5,"enabled":False,"maxAttenuation":-12,
                "release":250,"sensitivity":5},
}
