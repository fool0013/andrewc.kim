import wave, numpy as np

FS = 48000

def load(path):
    w = wave.open(path,'rb'); sr, ch = w.getframerate(), w.getnchannels()
    raw = np.frombuffer(w.readframes(w.getnframes()),dtype='<i2').astype(np.float64)/32768.
    x = raw.reshape(-1,ch)
    M = x.mean(axis=1)
    S = (x[:,0]-x[:,1])/2. if ch>1 else np.zeros_like(M)
    return sr, M, S

def frames(M, N=2048, hop=512):
    nf = 1+(len(M)-N)//hop
    idx = np.arange(N)[None,:]+hop*np.arange(nf)[:,None]
    return idx, nf

def levels(M):
    idx,nf = frames(M)
    return 10*np.log10(np.maximum((M[idx]**2).mean(axis=1),1e-20))

def voice_curve(M, S, sr, bands):
    N,hop = 2048,512; win=np.hanning(N)
    idx,nf = frames(M,N,hop)
    PM = np.abs(np.fft.rfft(M[idx]*win,axis=1))**2
    PS = np.abs(np.fft.rfft(S[idx]*win,axis=1))**2
    PV = np.maximum(PM-PS,0.) if np.any(S) else PM
    f  = np.fft.rfftfreq(N,1/sr)
    sb = (f>=300)&(f<3400)
    e  = 10*np.log10(np.maximum(PV[:,sb].sum(axis=1),1e-20))
    act, bed = e>=np.percentile(e,75), e<=np.percentile(e,15)
    vs  = np.maximum(PV[act].mean(axis=0)-PV[bed].mean(axis=0),1e-20)
    ref = 10*np.log10(vs[(f>=900)&(f<1100)].mean())
    keys = sorted(bands,key=int); hi=[int(k) for k in keys]+[12500]
    cur = {k: float(10*np.log10(vs[(f>=int(k))&(f<hi[i+1])].mean())-ref)
           for i,k in enumerate(keys)}
    lv = 10*np.log10(np.maximum((M[idx]**2).mean(axis=1),1e-20))
    return cur, lv[act], act.sum()

def peak_resp(freqs, f0, gain, q, fs=FS):
    if gain == 0: return np.zeros_like(freqs,dtype=float)
    A = 10**(gain/40.); w0 = 2*np.pi*f0/fs; al = np.sin(w0)/(2*q); c = np.cos(w0)
    b0,b1,b2 = 1+al*A, -2*c, 1-al*A
    a0,a1,a2 = 1+al/A, -2*c, 1-al/A
    w = 2*np.pi*freqs/fs; z = np.exp(-1j*w)
    H = (b0+b1*z+b2*z*z)/(a0+a1*z+a2*z*z)
    return 20*np.log10(np.abs(H))

GRID = {
 "low":  dict(freq=[125,150,175,200,225,250],                    q=[0.5,1,2,3,4.5]),
 "mid":  dict(freq=[400,450,500,600,700,800,900,1000,1150,1250], q=[0.5,1,2,2.5,3]),
 "high": dict(freq=[3000,4000,4650,5000,5650,6000,6250],          q=[0.5,1,2,3.5,5]),
}
GAINS = list(range(-12,13))

def fit(desired, fc, w):
    cur = {k: dict(frequency=GRID[k]["freq"][0], gain=0, q=1.0) for k in GRID}
    def total(exclude=None):
        t = np.zeros_like(fc)
        for k,v in cur.items():
            if k!=exclude: t += peak_resp(fc, v["frequency"], v["gain"], v["q"])
        return t
    prev = None
    for _ in range(6):
        for k in ("low","high","mid"):
            resid = desired - total(exclude=k)
            bb, be = None, None
            for f0 in GRID[k]["freq"]:
                for q in GRID[k]["q"]:
                    for g in GAINS:
                        err = float(np.sum(w*(resid-peak_resp(fc,f0,g,q))**2))
                        if be is None or err < be: be, bb = err, dict(frequency=f0,gain=g,q=q)
            cur[k] = bb
        e = float(np.sum(w*(desired-total())**2))
        if prev is not None and abs(prev-e) < 1e-6: break
        prev = e
    return cur, total()
