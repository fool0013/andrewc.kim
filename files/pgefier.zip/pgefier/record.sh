FF="${FFMPEG:-ffmpeg}"
OUT="${1:-myvoice.wav}"
"$FF" -nostdin -y -f dshow -i audio="Microphone (mic)" -t 60 -c:a pcm_s16le -ar 48000 "$OUT"
echo "wrote $OUT"
